#ifdef _MSC_VER
#define _CRT_SECURE_NO_WARNINGS
#endif

////memory leak detection ...
//#ifdef _DEBUG
//#define _CRTDBG_MAP_ALLOC
//#include <crtdbg.h>
//#include <stdlib.h>
//#endif

#include <cmath>
#include <algorithm>
#include <ctime>
#include <cstdlib>
#include <cstdio>
#include <vector>
#include <iomanip>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <conio.h>
#include "windows.h" //for a more accurate timer than clock()

#include "..\clipper.h"
#include "..\clipper_offset.h"
#include "svg.h"

using namespace std;
using namespace clipperlib;
using namespace svglib;

//------------------------------------------------------------------------------
// Miscellaneous function ...
//------------------------------------------------------------------------------

void PathFromStr(const string &s, Path &path)
{
  path.resize(0);
  size_t len = s.size(), i = 0, j;
  if (len == 0) return;
  while (i < len) {
    int64_t y = 0, x = 0;
    bool isNeg;
    while ((int)s[i] < 33 && i < len) i++;
    if (i >= len) break;
    //get x ...
    isNeg = (int)s[i] == 45;
    if (isNeg) i++;
    if (i >= len || (int)s[i] < 48 || (int)s[i] > 57) break;
    j = i;
    while (j < len && (int)s[j] > 47 && (int)s[j] < 58) {
      x = x * 10 + ((int)s[j] - 48);
      j++;
    }
    if (j == i) break;
    if (isNeg) x = -x;
    //skip space or comma between x & y ...
    i = j;
    while (i < len && ((int)s[i] == 32 || (int)s[i] == 44)) i++;
    //get y ...
    if (i >= len) break;
    isNeg = (int)s[i] == 45;
    if (isNeg) i++;
    if (i >= len || (int)s[i] < 48 || (int)s[i] > 57) break;
    j = i;
    while (j < len && (int)s[j] > 47 && (int)s[j] < 58) {
      y = y * 10 + ((int)s[j] - 48);
      j++;
    }
    if (j == i) break;
    if (isNeg) y = -y;
    path.push_back(Point64(x, y));
    //skip trailing space, comma ...
    i = j;
    while (i < len && ((int)s[i] == 32 || (int)s[i] == 44)) i++;
  }
}
//------------------------------------------------------------------------------

void PathFromStr(const string &s, Paths &paths)
{
  paths.resize(0);
  Path path;
  size_t len = s.size(), i = 0, j;
  if (len == 0) return;
  while (i < len) {
    int64_t y = 0, x = 0;
    bool isNeg;
    while ((int)s[i] < 33 && i < len) i++;
    if (i >= len) break;
    //get x ...
    isNeg = (int)s[i] == 45;
    if (isNeg) i++;
    if (i >= len || (int)s[i] < 48 || (int)s[i] > 57) break;
    j = i;
    while (j < len && (int)s[j] > 47 && (int)s[j] < 58) {
      x = x * 10 + ((int)s[j] - 48);
      j++;
    }
    if (j == i) break;
    if (isNeg) x = -x;
    //skip space or comma between x & y ...
    i = j;
    while (i < len && ((int)s[i] == 32 || (int)s[i] == 44)) i++;
    //get y ...
    if (i >= len) break;
    isNeg = (int)s[i] == 45;
    if (isNeg) i++;
    if (i >= len || (int)s[i] < 48 || (int)s[i] > 57) break;
    j = i;
    while (j < len && (int)s[j] > 47 && (int)s[j] < 58) {
      y = y * 10 + ((int)s[j] - 48);
      j++;
    }
    if (j == i) break;
    if (isNeg) y = -y;
    path.push_back(Point64(x, y));

    //skip trailing space, comma ...
    i = j;
    int nlCnt = 0;
    while (i < len && ((int)s[i] < 33 || (int)s[i] == 44)) {
      if (i >= len) break;
      if ((int)s[i] == 10) {
        nlCnt++;
        if (nlCnt == 2) {
          if (path.size() > 2) paths.push_back(path);
          path.resize(0);
        }
      }
      i++;
    }
  }
  if (path.size() > 2)  paths.push_back(path);
}
//------------------------------------------------------------------------------

bool GetNum(string &line, size_t &start_pos, int64_t &value)
{
  value = 0;
  size_t line_len = line.size();
  while (start_pos < line_len && line[start_pos] == ' ') ++start_pos;
  if (start_pos >= line_len) return false;
  bool is_neg = (line[start_pos] == '-');
  if (is_neg) ++start_pos;
  size_t num_start_pos = start_pos;
  while (start_pos < line_len && line[start_pos] >= '0' && line[start_pos] <= '9') {
    value = value * 10 + (int)line[start_pos] - 48;
    ++start_pos;
  }
  if (start_pos == num_start_pos) return false; //no value
  if (start_pos < line_len && line[start_pos] == ',') ++start_pos;
  if (is_neg) value = -value;
  return true;
}
//------------------------------------------------------------------------------

bool GetPath(string &line, Paths &paths)
{
  size_t line_pos = 0, line_len = line.size();
  Path p;
  int64_t x = 0, y = 0;
  while (GetNum(line, line_pos, x) && GetNum(line, line_pos, y))
    p.push_back(Point64(x, y));
  if (p.empty()) return false; 
  paths.push_back(p);
  return true;
}
//------------------------------------------------------------------------------

inline bool GetLine(ifstream &source, int &last_line_pos, string &line) {
  if (source.eof()) return false;
  source.clear();
  last_line_pos = (int)source.tellg();
  getline(source, line);
  return true;
}
//------------------------------------------------------------------------------

bool GetTestNum(ifstream &source, int test_num, bool seek_from_start,
  Paths &subj, Paths &subj_open, Paths &clip, Paths &solution, Paths &solution_open, 
  ClipType &ct , FillRule &fr)
{
  string line;
  bool found = false;
  if (seek_from_start) source.seekg(0, ios_base::beg);
  int start_of_line_pos = 0;
  while (GetLine(source, start_of_line_pos, line)) {
    size_t pos = line.find("CAPTION:");
    if (pos == string::npos) continue;
    pos += 8;
    size_t line_len = line.size();
    int64_t num = 0;
    if (!GetNum(line, pos, num)) continue;
    if (num > test_num) return false;
    if (num != test_num) continue;

    found = true;
    subj.clear(); subj_open.clear(); clip.clear(); 
    solution.clear();  solution_open.clear();

    while (GetLine(source, start_of_line_pos, line)) {
      //stop if we've arrived at the next test ...
      if (line.find("CAPTION:") != string::npos) {
        //go back a line ready for the next GetTestNum() ...
        source.seekg(start_of_line_pos, ios_base::beg);
        return true;
      }

      if (line.find("INTERSECTION") != string::npos) {
        ct = ctIntersection; continue;
      }
      else if (line.find("UNION") != string::npos) {
        ct = ctUnion; continue;
      }
      else if (line.find("DIFFERENCE") != string::npos) {
        ct = ctDifference; continue;
      }
      else if (line.find("XOR") != string::npos) {
        ct = ctXor; continue;
      }

      if (line.find("EVENODD") != string::npos) {
        fr = frEvenOdd; continue;
      }
      else if (line.find("NONZERO") != string::npos) {
        fr = frNonZero; continue;
      }
      else if (line.find("POSITIVE") != string::npos) {
        fr = frPositive; continue;
      }
      else if (line.find("NEGATIVE") != string::npos) {
        fr = frNegative; continue;
      }

      if (line.find("SUBJECTS_OPEN") != string::npos) {
        while (getline(source, line) && GetPath(line, subj_open));
      }
      else if (line.find("SUBJECTS") != string::npos) {
        while (getline(source, line) && GetPath(line, subj));
      }
      if (line.find("CLIPS") != string::npos) {
        while (getline(source, line) && GetPath(line, clip));
      }
      if (line.find("SOLUTION_OPEN") != string::npos) {
        while (getline(source, line) && GetPath(line, solution_open));
      }
      else if (line.find("SOLUTION") != string::npos) {
        while (getline(source, line) && GetPath(line, solution));
      }
    } //inner while still lines (found)
  } //outer while still lines (not found)
  return found;
}
//------------------------------------------------------------------------------

inline int Loop(int val, int loop_val)
{
  return val % loop_val;
}
//------------------------------------------------------------------------------

void GetPaths(stringstream &ss, Paths &paths)
{
  for (;;) { //for each path (line) ...
    Path p;
    for (;;) { //for each point
      int64_t x, y;
      char char_buf;
      int c = ss.peek();
      if (c == EOF) return;
      if (c < ' ') { //assume one or more newline chars
        ss.read(&char_buf, 1);
        break;
      }
      if (!(c == '-' || (c >= '0' && c <= '9'))) return;
      if (!(ss >> x)) return; //oops!
      c = ss.peek();
      if (c != ',') return;
      ss.read(&char_buf, 1); //gobble comma
      if (!(ss >> y)) return; //oops!
      p.push_back(Point64(x, y));
      c = ss.peek();
      if (c != ' ') break;
      ss.read(&char_buf, 1); //gobble space
    }
    if (p.size() > 2) paths.push_back(p);
    p.clear();
  }
}
//------------------------------------------------------------------------------

bool LoadFromFile(const string& filename, Paths &subj, Paths &clip, ClipType &ct, FillRule &fr)
{
  subj.clear();
  clip.clear();
  ifstream file(filename);
	if (!file.is_open()) return false;
  stringstream ss;
  ss << file.rdbuf();
  file.close();

  string line;
  bool cap_found = false;
  for (;;){
    if (!std::getline(ss, line)) return true;
    if (!cap_found ) {
      if (line.find("CAPTION: ") != std::string::npos) cap_found = true;
      continue;
    }
    if (line.find("CLIPTYPE:") != std::string::npos) {
      if (line.find("INTERSECTION") != std::string::npos) ct = ctIntersection;
      else if (line.find("UNION") != std::string::npos) ct = ctUnion;
      else if (line.find("DIFFERENCE") != std::string::npos) ct = ctDifference;
      else ct = ctXor;
    }
    else if (line.find("FILLRULE:") != std::string::npos) {
      if (line.find("EVENODD") != std::string::npos) fr = frEvenOdd;
      else fr = frNonZero;
    }
    else if (line.find("SUBJECTS") != std::string::npos) GetPaths(ss, subj);
    else if (line.find("CLIPS") != std::string::npos) GetPaths(ss, clip);
    else return true;
  }
  return true;
}
//------------------------------------------------------------------------------

void PathToString(Path &path, string &str) {
  ostringstream ss;
  for (Path::iterator path_it = path.begin(); path_it != path.end(); path_it++)
    ss << path_it->x << "," << path_it->y << " ";
  str = ss.str();
}
//------------------------------------------------------------------------------

void SaveToFile(const string &filename, Paths &subj, Paths &clip, ClipType ct, FillRule fr)
{
  string cliptype;
  string fillrule;
  switch (ct) {
  case ctNone: cliptype = "NONE"; break;
  case ctIntersection: cliptype = "INTERSECTION"; break;
  case ctUnion: cliptype = "UNION"; break;
  case ctDifference: cliptype = "DIFFERENCE"; break;
  case ctXor: cliptype = "XOR"; break;
  }
  switch (fr) {
  case frEvenOdd: fillrule = "EVENODD"; break;
  case frNonZero: fillrule = "NONZERO"; break;
  }

  std::ofstream file;
  file.open(filename);
  file << "CAPTION: " << cliptype << " " << fillrule << '\n';
  file << "CLIPTYPE: " << cliptype << '\n';
  file << "FILLRULE: " << fillrule << '\n';
  file << "SUBJECTS\n";
  for (Paths::iterator paths_it = subj.begin(); paths_it != subj.end(); paths_it++) {
    string s;
    PathToString(*paths_it, s);
    file << s << '\n';
  }
  file << "CLIPS\n";
  for (Paths::iterator paths_it = clip.begin(); paths_it != clip.end(); paths_it++) {
    string s;
    PathToString(*paths_it, s);
    file << s << '\n';
  }
  file.close();
}
//------------------------------------------------------------------------------

void MakeRandomPoly(int edgeCount, int width, int height, Paths & poly)
{
	//rounds coords to nearest multiple of 10 ...
  poly.resize(1);
	poly[0].resize(edgeCount);
	for (int i = 0; i < edgeCount; i++) {
		poly[0][i].x = (int64_t)round((rand() % (width / 10))) * 10;
		poly[0][i].y = (int64_t)round((rand() % (height / 10))) * 10;
	}
}
//------------------------------------------------------------------------------

double Area(const Path path)
{
  size_t cnt = path.size();
  if (cnt < 3) return 0.0;
  int j = cnt - 1;
  double result = 0.0;
  for (size_t i = 0; i < cnt; ++i)
  {
    double d = (double)(path[j].x + path[i].x);
    result += d * (path[j].y - path[i].y);
    j = i;
  }
  return -result * 0.5;
}
//------------------------------------------------------------------------------

void SaveToSVG(const string filename, int max_width, int max_height, 
  Paths &subj, Paths &subj_open, Paths &clip, Paths &solution, Paths &solution_open,
  FillRule fill_rule, bool show_coords = false)
{
  SVGBuilder svg;
  svg.fill_rule = fill_rule;
  svg.SetCoordsStyle("Verdana", 0xFF0000AA, 9);
  svg.AddCaption("Clipper demo ...", 0xFF000000, 14, 20, 20);
  svg.AddPaths(subj, false, 0x1200009C, 0xCCD3D3DA, 0.8, show_coords);
  svg.AddPaths(subj_open, true, 0x0, 0xFFD3D3DA, 1.0, show_coords);
  svg.AddPaths(clip, false, 0x129C0000, 0xCCFFA07A, 0.8, show_coords);
  svg.AddPaths(solution, false, 0x6080ff9C, 0xFF003300, 0.8, show_coords);
  //for (Paths::const_iterator i = solution.cbegin(); i != solution.cend(); ++i)
  //  if (Area(*i) < 0) svg.AddPath((*i), false, 0x0, 0xFFFF0000, 0.8, show_coords);
  svg.AddPaths(solution_open, true, 0x0, 0xFF000000, 1.0, show_coords);
  svg.SaveToFile(filename, max_width, max_height, 80);
}
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// Main entry point ...
//------------------------------------------------------------------------------

int main(int argc, char* argv[])
{
    int display_width = 800, display_height = 600;
    bool show_cords = false;//true;//  //don't this if there are hundreds or thousands of coords :)

    //nest this block to scope Clipper so we can more easily see any memory leaks 
    {
      srand((unsigned)time(0));
      Paths subject, subject_open, clip, solution_old, solution_open_old, solution, solution_open;
      
      ClipType ct = ctIntersection;
      FillRule fr = frNonZero;

      //  ////////////////////////////////////////////////////////////////////////////
      //  single test ...
      //  ///////////////////////////////////////////////////////////////////////////

      ////subject.resize(1);
      ////clip.resize(1);
      ////PathFromStr("643,281 791,365 1094,295 1064,155 618,365 54,153 1031,232 669,639 413,177 770,522", subject[0]);
      ////PathFromStr("200,200, 400,200 400,400, 200,400", clip[0]);

      //LoadFromFile("temp.txt", subject, clip, ct, fr);
      //Clipper clipper;
      //clipper.AddPaths(subject, ptSubject);
      //clipper.AddPaths(clip, ptClip);
      //clipper.Execute(ct, solution, fr);

      //OffsetPaths(solution, solution, 50, kSquare, kPolygon);

      //  ////////////////////////////////////////////////////////////////////////////
      //  //run tests.txt check-up ...
      //  ////////////////////////////////////////////////////////////////////////////

      //ifstream ifs("tests2.txt");
      //if (!ifs) return false;
      //int j = 0, start_num = 1, cnt = 1;
      //for (int i = start_num; cnt-- > 0; ++i) {
      //  if (GetTestNum(ifs, i, false, subject, subject_open, clip, 
      //      solution_old, solution_open_old, ct, fr)) {
      //    Clipper c;
      //    if (!subject.empty()) c.AddPaths(subject, ptSubject);
      //    //if (!subject_open.empty()) c.AddPaths(subject_open, kSubject, true);
      //    if (!clip.empty()) c.AddPaths(clip, ptClip);
      //    c.Execute(ct, solution);
      //    string filename = "test_" + to_string(start_num + j) + ".svg";
      //    SaveToSVG(filename, display_width, display_height,
      //      subject, subject_open, clip, solution, solution_open, frEvenOdd, show_cords);
      //    system(filename.c_str());
      //    ++j;
      //    //if (!PathsMatch(solution_old, solution, false))
      //    //  DisplaySolutionMismatch(i, solution_old, solution, false);
      //    //if (!PathsMatch(solution_open_old, solution_open, true))
      //    //  DisplaySolutionMismatch(i, solution_open_old, solution_open, false);
      //    }
      //    else break;
      //  }
      //if (cnt > 0 && !ifs.eof()) printf("Oops, something broke.\n");
      //printf("%d tests completed\n", j);
      //return 0;

      ////////////////////////////////////////////////////////////////////////////
      //random tests (timed)
      ////////////////////////////////////////////////////////////////////////////

      //Clipper1 clipper; //this is the old Clipper (ver 6.4.2)
      Clipper clipper; //this is the new clipper !!!

      #ifdef WIN32
      LARGE_INTEGER StartingTime, EndingTime, ElapsedMilliseconds, Frequency;
      QueryPerformanceFrequency(&Frequency);
      QueryPerformanceCounter(&StartingTime);
      #else
      time_t time_start = clock();
      #endif

      /************************************************************************/
      int edge_cnt = 50;
      int loops = 1;
      ct = ctIntersection;//ctUnion;//
      fr = frEvenOdd;//frNonZero;//
      show_cords = false;//true;//
      /************************************************************************/

      for (int i = 0; i < loops; ++i) {
        MakeRandomPoly(edge_cnt, display_width, display_height, subject);
        MakeRandomPoly(edge_cnt, display_width, display_height, clip);
        SaveToFile("temp.txt", subject, clip, ct, fr);
        clipper.Clear();
        clipper.AddPaths(subject, ptSubject);
        clipper.AddPaths(clip, ptClip);
        clipper.Execute(ct, solution, fr);
      }
      #ifdef WIN32
      QueryPerformanceCounter(&EndingTime);
      ElapsedMilliseconds.QuadPart = EndingTime.QuadPart - StartingTime.QuadPart;
      ElapsedMilliseconds.QuadPart *= 1000;
      ElapsedMilliseconds.QuadPart /= Frequency.QuadPart;
      cout << "\nFinished in " << ElapsedMilliseconds.QuadPart << " msecs.\n\n";
      #else
      double time_elapsed = ((double)clock() - time_start) * 1000 / CLOCKS_PER_SEC;
      cout << "\nFinished in " << time_elapsed << " msecs.\n\n";
      #endif

      //////////////////////////////////////////////////////////////////////////
      //and display the final clipping op as an image too 
      //unless it's likely to be a very big file ...
      if (ElapsedMilliseconds.QuadPart < 1000) {
        SaveToSVG("solution.svg", display_width, display_height,
          subject, subject_open, clip, solution, solution_open, fr, show_cords);
        system("solution.svg");
      }
      //////////////////////////////////////////////////////////////////////////
      //////////////////////////////////////////////////////////////////////////
      //_getch();
    }

    //#ifdef _DEBUG
    ////nb: 2 static string const in SVG.cpp clutter memory leak reports 
    ////so remove the SVG unit when leak testing ...
    //_CrtDumpMemoryLeaks();
    //#endif

    return 0;
}
//---------------------------------------------------------------------------
