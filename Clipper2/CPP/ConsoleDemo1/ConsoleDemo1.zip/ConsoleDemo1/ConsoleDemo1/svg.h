/*******************************************************************************
*                                                                              *
* Author    :  Angus Johnson                                                   *
* Date      :  18 September 2017                                               *
* Website   :  http://www.angusj.com                                           *
* Copyright :  Angus Johnson 2010-2017                                         *
*                                                                              *
* License:                                                                     *
* Use, modification & distribution is subject to Boost Software License Ver 1. *
* http://www.boost.org/LICENSE_1_0.txt                                         *
*                                                                              *
*******************************************************************************/

#ifndef svglib_h
#define svglib_h

#include <cmath>
#include <algorithm>
#include <ctime>
#include <cstdlib>
#include <cstdio>
#include <vector>
#include <iomanip>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include "clipper.h"

namespace svglib {

  //---------------------------------------------------------------------------
  // SVGBuilder: a very simple class that creates an SVG image file
  //---------------------------------------------------------------------------

  class SVGBuilder
  {
    class StyleInfo {
    private:
      unsigned brush_color_;
      unsigned pen_color_;
      double pen_width_;
      bool show_coords_;
    public:
      StyleInfo(unsigned brush_clr, unsigned pen_clr, double pen_width, bool show_coords) :
        brush_color_(brush_clr), pen_color_(pen_clr), pen_width_(pen_width), show_coords_(show_coords) {};
      friend class SVGBuilder;
    };

    class PathInfo {
    private:
      StyleInfo style_;
      clipperlib::Paths paths_;
      bool is_open_path;
    public:
      PathInfo(clipperlib::Paths &paths, bool is_open, StyleInfo &style) :
        paths_(paths), is_open_path(is_open), style_(style) {};
      friend class SVGBuilder;
    };

    typedef std::vector< PathInfo* > PathInfoList;
  private:
    PathInfoList path_info_list_;
  public:
    SVGBuilder() { fill_rule = clipperlib::kEvenOdd; };
    ~SVGBuilder() { Clear(); };

    clipperlib::FillRule fill_rule;

    void AddPaths(clipperlib::Paths &paths, bool is_open,
      unsigned brushClr, unsigned pen_color, double pen_width, bool show_coords);
    void Clear();
    bool SaveToFile(const std::string &filename, int max_width, int max_height, int margin);
  }; //class

} //namespace

#endif //svglib_h
