#ifdef _MSC_VER
#define _CRT_SECURE_NO_WARNINGS
#endif

////memory leak detection ...
//#ifdef _DEBUG
//#define _CRTDBG_MAP_ALLOC
//#include <crtdbg.h>
//#include <stdlib.h>
//#endif

#include <cmath>
#include <algorithm>
#include <ctime>
#include <cstdlib>
#include <cstdio>
#include <vector>
#include <iomanip>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <conio.h>
#include "svg.h"
#include "clipper.h"
#include "clipper_offset.h"

#ifdef WIN32
  #include "windows.h" //for a more accurate timer than clock()
#endif

using namespace std;
using namespace clipperlib;
using namespace svglib;

//------------------------------------------------------------------------------
// Miscellaneous function ...
//------------------------------------------------------------------------------

void PathFromStr(const string &s, Path &path)
{
  path.resize(0);
  size_t len = s.size(), i = 0, j;
  if (len == 0) return;
  while (i < len) {
    int64_t y = 0, x = 0;
    bool isNeg;
    while ((int)s[i] < 33 && i < len) i++;
    if (i >= len) break;
    //get x ...
    isNeg = (int)s[i] == 45;
    if (isNeg) i++;
    if (i >= len || (int)s[i] < 48 || (int)s[i] > 57) break;
    j = i;
    while (j < len && (int)s[j] > 47 && (int)s[j] < 58) {
      x = x * 10 + ((int)s[j] - 48);
      j++;
    }
    if (j == i) break;
    if (isNeg) x = -x;
    //skip space or comma between x & y ...
    i = j;
    while (i < len && ((int)s[i] == 32 || (int)s[i] == 44)) i++;
    //get y ...
    if (i >= len) break;
    isNeg = (int)s[i] == 45;
    if (isNeg) i++;
    if (i >= len || (int)s[i] < 48 || (int)s[i] > 57) break;
    j = i;
    while (j < len && (int)s[j] > 47 && (int)s[j] < 58) {
      y = y * 10 + ((int)s[j] - 48);
      j++;
    }
    if (j == i) break;
    if (isNeg) y = -y;
    path.push_back(Point64(x, y));
    //skip trailing space, comma ...
    i = j;
    while (i < len && ((int)s[i] == 32 || (int)s[i] == 44)) i++;
  }
}
//------------------------------------------------------------------------------

void PathFromStr(const string &s, Paths &paths)
{
  paths.resize(0);
  Path path;
  size_t len = s.size(), i = 0, j;
  if (len == 0) return;
  while (i < len) {
    int64_t y = 0, x = 0;
    bool isNeg;
    while ((int)s[i] < 33 && i < len) i++;
    if (i >= len) break;
    //get x ...
    isNeg = (int)s[i] == 45;
    if (isNeg) i++;
    if (i >= len || (int)s[i] < 48 || (int)s[i] > 57) break;
    j = i;
    while (j < len && (int)s[j] > 47 && (int)s[j] < 58) {
      x = x * 10 + ((int)s[j] - 48);
      j++;
    }
    if (j == i) break;
    if (isNeg) x = -x;
    //skip space or comma between x & y ...
    i = j;
    while (i < len && ((int)s[i] == 32 || (int)s[i] == 44)) i++;
    //get y ...
    if (i >= len) break;
    isNeg = (int)s[i] == 45;
    if (isNeg) i++;
    if (i >= len || (int)s[i] < 48 || (int)s[i] > 57) break;
    j = i;
    while (j < len && (int)s[j] > 47 && (int)s[j] < 58) {
      y = y * 10 + ((int)s[j] - 48);
      j++;
    }
    if (j == i) break;
    if (isNeg) y = -y;
    path.push_back(Point64(x, y));

    //skip trailing space, comma ...
    i = j;
    int nlCnt = 0;
    while (i < len && ((int)s[i] < 33 || (int)s[i] == 44)) {
      if (i >= len) break;
      if ((int)s[i] == 10) {
        nlCnt++;
        if (nlCnt == 2) {
          if (path.size() > 2) paths.push_back(path);
          path.resize(0);
        }
      }
      i++;
    }
  }
  if (path.size() > 2)  paths.push_back(path);
}
//------------------------------------------------------------------------------

bool GetNum(string &line, size_t &start_pos, int64_t &value)
{
  value = 0;
  size_t line_len = line.size();
  while (start_pos < line_len && line[start_pos] == ' ') ++start_pos;
  if (start_pos >= line_len) return false;
  bool is_neg = (line[start_pos] == '-');
  if (is_neg) ++start_pos;
  size_t num_start_pos = start_pos;
  while (start_pos < line_len && line[start_pos] >= '0' && line[start_pos] <= '9') {
    value = value * 10 + (int)line[start_pos] - 48;
    ++start_pos;
  }
  if (start_pos == num_start_pos) return false; //no value
  if (start_pos < line_len && line[start_pos] == ',') ++start_pos;
  if (is_neg) value = -value;
  return true;
}
//------------------------------------------------------------------------------

bool GetPath(string &line, Paths &paths)
{
  size_t line_pos = 0, line_len = line.size();
  Path p;
  int64_t x = 0, y = 0;
  while (GetNum(line, line_pos, x) && GetNum(line, line_pos, y))
    p.push_back(Point64(x, y));
  if (p.empty()) return false; 
  paths.push_back(p);
  return true;
}
//------------------------------------------------------------------------------

inline bool GetLine(ifstream &source, int &last_line_pos, string &line) {
  if (source.eof()) return false;
  source.clear();
  last_line_pos = (int)source.tellg();
  getline(source, line);
  return true;
}
//------------------------------------------------------------------------------

bool GetTestNum(ifstream &source, int test_num, bool seek_from_start,
  Paths &subj, Paths &subj_open, Paths &clip, Paths &solution, Paths &solution_open, 
  ClipType &ct , FillRule &fr)
{
  string line;
  bool found = false;
  if (seek_from_start) source.seekg(0, ios_base::beg);
  int start_of_line_pos = 0;
  while (GetLine(source, start_of_line_pos, line)) {
    size_t pos = line.find("CAPTION:");
    if (pos == string::npos) continue;
    pos += 8;
    size_t line_len = line.size();
    int64_t num = 0;
    if (!GetNum(line, pos, num)) continue;
    if (num > test_num) return false;
    if (num != test_num) continue;

    found = true;
    subj.clear(); subj_open.clear(); clip.clear(); 
    solution.clear();  solution_open.clear();

    while (GetLine(source, start_of_line_pos, line)) {
      //stop if we've arrived at the next test ...
      if (line.find("CAPTION:") != string::npos) {
        //go back a line ready for the next GetTestNum() ...
        source.seekg(start_of_line_pos, ios_base::beg);
        return true;
      }

      if (line.find("INTERSECTION") != string::npos) {
        ct = kIntersection; continue;
      }
      else if (line.find("UNION") != string::npos) {
        ct = kUnion; continue;
      }
      else if (line.find("DIFFERENCE") != string::npos) {
        ct = kDifference; continue;
      }
      else if (line.find("XOR") != string::npos) {
        ct = kXor; continue;
      }

      if (line.find("EVENODD") != string::npos) {
        fr = kEvenOdd; continue;
      }
      else if (line.find("NONZERO") != string::npos) {
        fr = kNonZero; continue;
      }
      else if (line.find("POSITIVE") != string::npos) {
        fr = kPositive; continue;
      }
      else if (line.find("NEGATIVE") != string::npos) {
        fr = kNegative; continue;
      }

      if (line.find("SUBJECTS_OPEN") != string::npos) {
        while (getline(source, line) && GetPath(line, subj_open));
      }
      else if (line.find("SUBJECTS") != string::npos) {
        while (getline(source, line) && GetPath(line, subj));
      }
      if (line.find("CLIPS") != string::npos) {
        while (getline(source, line) && GetPath(line, clip));
      }
      if (line.find("SOLUTION_OPEN") != string::npos) {
        while (getline(source, line) && GetPath(line, solution_open));
      }
      else if (line.find("SOLUTION") != string::npos) {
        while (getline(source, line) && GetPath(line, solution));
      }
    } //inner while still lines (found)
  } //outer while still lines (not found)
  return found;
}
//------------------------------------------------------------------------------

inline int Loop(int val, int loop_val)
{
  return val % loop_val;
}
//------------------------------------------------------------------------------

bool PathMatch(const Path &path1, const Path &path2, bool is_open)
{
  int j = 0, len = path1.size();
  if (path2.size() != len) return false;
  if (len == 0) return true;
  if (!is_open) {
    while (j < len && (path1[0] != path2[j])) ++j;
    if (j == len) return false;
  }
  for (int i = 0; i < len; ++i)
    if (path1[i] != path2[Loop(j++, len)]) return false;
  return true;
}
//------------------------------------------------------------------------------

bool PathsMatch(const Paths &paths1, const Paths &paths2, bool is_open)
{
  if (paths1.size() != paths2.size()) return false;
  for (size_t i = 0; i < paths1.size(); ++i)
    if (!PathMatch(paths1[i], paths2[i], is_open)) return false;
  return true;
}
//------------------------------------------------------------------------------

bool LoadFromFile(Paths &ppg, const string& filename, double scale)
{
	//file format assumes: 
	//  1. path coordinates (x,y) are comma separated (+/- spaces) and 
	//  each coordinate is on a separate line
	//  2. each path is separated by one or more blank lines

	ppg.clear();
	ifstream ifs(filename);
	if (!ifs) return false;
	string line;
	Path pg;
	while (std::getline(ifs, line)) {
		stringstream ss(line);
		double x = 0.0, y = 0.0;
		if (!(ss >> x)) {
			//ie blank lines => flag start of next polygon 
			if (pg.size() > 0) ppg.push_back(pg);
			pg.clear();
			continue;
		}
		char c = ss.peek();
		while (c == ' ') { ss.read(&c, 1); c = ss.peek(); } //gobble spaces before comma
		if (c == ',') { ss.read(&c, 1); c = ss.peek(); } //gobble comma
		while (c == ' ') { ss.read(&c, 1); c = ss.peek(); } //gobble spaces after comma
		if (!(ss >> y)) break; //oops!
		pg.push_back(Point64((int64_t)(x * scale), (int64_t)(y * scale)));
	}
	if (pg.size() > 0) ppg.push_back(pg);
	ifs.close();
	return true;
}
//------------------------------------------------------------------------------

void MakeRandomPoly(int edgeCount, int width, int height, Paths & poly)
{
	//rounds coords to nearest multiple of 10 ...
  poly.resize(1);
	poly[0].resize(edgeCount);
	for (int i = 0; i < edgeCount; i++) {
		poly[0][i].x = (int64_t)round((rand() % (width / 10))) * 10;
		poly[0][i].y = (int64_t)round((rand() % (height / 10))) * 10;
	}
}
//------------------------------------------------------------------------------

void SaveToSVG(const string filename, int max_width, int max_height, 
  Paths &subj, Paths &subj_open, Paths &clip, Paths &solution, Paths &solution_open,
  FillRule fill_rule, bool show_coords = false)
{
  SVGBuilder svg;
  svg.fill_rule = fill_rule;
  svg.AddPaths(subj, false, 0x1200009C, 0xCCD3D3DA, 0.8, show_coords);
  svg.AddPaths(subj_open, true, 0x0, 0xFFD3D3DA, 1.0, show_coords);
  svg.AddPaths(clip, false, 0x129C0000, 0xCCFFA07A, 0.8, show_coords);
  svg.AddPaths(solution, false, 0x6080ff9C, 0xFF003300, 0.8, show_coords);
  svg.AddPaths(solution_open, true, 0x0, 0xFF000000, 1.0, show_coords);
  svg.SaveToFile(filename, max_width, max_height, 80);
}
//------------------------------------------------------------------------------

void DisplaySolutionMismatch(int test_num, Paths old_path, Paths new_path, bool is_open)
{
  stringstream ss_old, ss_new;
  string path_type = is_open ? "Open" : "Closed";
  printf("%s path mismatch in %d\n", path_type.c_str(), test_num);
  if (!old_path.empty()) {
    ss_old << old_path;
    printf("Stored solution:\n");
    printf("%s\n", ss_old.str().c_str());
    ss_old.str("");
  }
  if (!new_path.empty()) {
    ss_new << new_path;
    printf("New solution:\n");
    printf("%s\n", ss_new.str().c_str());
    ss_new.str("");
  }
}

//------------------------------------------------------------------------------
// Main entry point ...
//------------------------------------------------------------------------------

int main(int argc, char* argv[])
{
    srand((unsigned)time(0));
    int edge_cnt = 10, display_width = 800, display_height = 600, loops = 1;
    bool show_cords = false; //don't if there are hundreds or thousands of coords :)

    //nest this block to scope Clipper so we can more easily see any memory leaks 
    {
      Paths subject, subject_open, clip, solution_old, solution_open_old, solution, solution_open;
      
      ClipType ct = kIntersection;
      FillRule fr = kEvenOdd;

      //  ////////////////////////////////////////////////////////////////////////////
      //  single test ...
      //  ////////////////////////////////////////////////////////////////////////////

      //subject.resize(1);
      //PathFromStr("100,100 1000,100, 1000,1000, 100,1000", subject[0]);
      //clip.resize(1);
      //PathFromStr("200,200, 1100,200 1100,1100, 200,1100", clip[0]);
      //Clipper clipper;
      //clipper.Clear();
      //clipper.AddPaths(subject, kSubject);
      //clipper.AddPaths(clip, kClip);
      //clipper.Execute(kIntersection, solution, solution_open, kEvenOdd);
      //
      //OffsetPaths(solution, solution, 50, kSquare, kPolygon);

      //  ////////////////////////////////////////////////////////////////////////////
      //  //run tests.txt check-up ...
      //  ////////////////////////////////////////////////////////////////////////////

      //ifstream ifs("tests.txt");
      //if (!ifs) return false;
      //int j = 0, start_num = 1, cnt = 6;
      //for (int i = start_num; cnt-- > 0; ++i) {
      //  if (GetTestNum(ifs, i, false, subject, subject_open, clip, 
      //      solution_old, solution_open_old, ct, fr)) {
      //    Clipper c;
      //    if (!subject.empty()) c.AddPaths(subject, kSubject);
      //    if (!subject_open.empty()) c.AddPaths(subject_open, kSubject, true);
      //    if (!clip.empty()) c.AddPaths(clip, kClip);
      //    c.Execute(ct, solution, solution_open);
      //    ++j;
      //    if (!PathsMatch(solution_old, solution, false))
      //      DisplaySolutionMismatch(i, solution_old, solution, false);
      //    if (!PathsMatch(solution_open_old, solution_open, true))
      //      DisplaySolutionMismatch(i, solution_open_old, solution_open, false);
      //    }
      //    else break;
      //  }
      //if (cnt > 0 && !ifs.eof()) printf("Oops, something broke.\n", j);
      //printf("%d tests completed\n", j);

      //  ////////////////////////////////////////////////////////////////////////////
      //  //random tests (timed)
      //  ////////////////////////////////////////////////////////////////////////////

      //Clipper1 clipper; //this is the old Clipper (ver 6.4.2)
      Clipper clipper; //this is the new clipper !!!

      #ifdef WIN32
      LARGE_INTEGER StartingTime, EndingTime, ElapsedMilliseconds, Frequency;
      QueryPerformanceFrequency(&Frequency);
      QueryPerformanceCounter(&StartingTime);
      #else
      time_t time_start = clock();
      #endif

      for (int i = 0; i < loops; ++i) {
        MakeRandomPoly(edge_cnt, display_width, display_height, subject);
        MakeRandomPoly(edge_cnt, display_width, display_height, clip);
        //SaveToFile("subj.txt", subject);
        //SaveToFile("clip.txt", clip);

        clipper.Clear();
        clipper.AddPaths(subject, kSubject);
        clipper.AddPaths(clip, kClip);
        try
        {
          clipper.Execute(kIntersection, solution, kEvenOdd);
        }
        catch (exception)
        {
          //SaveToFile("subj.txt", subject);
          //SaveToFile("clip.txt", clip);
        }

      }
      #ifdef WIN32
      QueryPerformanceCounter(&EndingTime);
      ElapsedMilliseconds.QuadPart = EndingTime.QuadPart - StartingTime.QuadPart;
      ElapsedMilliseconds.QuadPart *= 1000;
      ElapsedMilliseconds.QuadPart /= Frequency.QuadPart;
      cout << "\nFinished in " << ElapsedMilliseconds.QuadPart << " msecs.\n\n";
      #else
      double time_elapsed = ((double)clock() - time_start) * 1000 / CLOCKS_PER_SEC;
      cout << "\nFinished in " << time_elapsed << " msecs.\n\n";
      #endif

      //////////////////////////////////////////////////////////////////////////
      //and display the final clipping op as an image too ...
      SaveToSVG("solution.svg", display_width, display_height,
        subject, subject_open, clip, solution, solution_open, kEvenOdd, show_cords);
      system("solution.svg");

      //_getch();
      //////////////////////////////////////////////////////////////////////////
      //////////////////////////////////////////////////////////////////////////
    }

    //#ifdef _DEBUG
    ////nb: 2 static string const in SVG.cpp clutter memory leak reports 
    ////so remove the SVG unit when leak testing ...
    //_CrtDumpMemoryLeaks();
    //#endif

    return 0;
}
//---------------------------------------------------------------------------
