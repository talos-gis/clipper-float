// temp2.cpp : Defines the entry point for the application.
//

#include "stdafx.h"
#include "resource.h"
#include <cmath>
#include <algorithm>
#include <ctime>
#include <string>
#include <sstream>
#include <iomanip>
#include <istream>
#include <fstream>
#include <conio.h>
#include <gl/gl.h>

#include "..\clipper.h"
#include "..\clipper_offset.h"
#include "..\clipper_triangulation.h"

#pragma comment(lib, "opengl32.lib")

#define MAX_LOADSTRING 100

using namespace std;
using namespace clipperlib;

// Global Variables:
HINSTANCE hInst;                                // current instance
HWND mainHdl;
HGLRC hglrc;                                    // handle to OpenGL rendering context
WCHAR szTitle[MAX_LOADSTRING];                  // The title bar text
WCHAR szWindowClass[MAX_LOADSTRING];            // the main window class name
HCURSOR cursors[2];
// Forward declarations of functions included in this code module:
ATOM                MyRegisterClass(HINSTANCE hInstance);
HWND                InitInstance(HINSTANCE, int);
LRESULT CALLBACK    WndProc(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK    About(HWND, UINT, WPARAM, LPARAM);
void Draw(int max_width, int max_height);
void ForceRedraw();
void ResizingMainWnd(int width, int height);

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------

int APIENTRY wWinMain(_In_ HINSTANCE hInstance,
                     _In_opt_ HINSTANCE hPrevInstance,
                     _In_ LPWSTR    lpCmdLine,
                     _In_ int       nCmdShow)
{

  UNREFERENCED_PARAMETER(hPrevInstance);
  UNREFERENCED_PARAMETER(lpCmdLine);
  hInst = hInstance;

  // Initialize global strings
  LoadStringW(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
  LoadStringW(hInstance, IDC_OPENGLDEMO, szWindowClass, MAX_LOADSTRING);
  MyRegisterClass(hInstance);  
  cursors[0] = LoadCursor(NULL, IDC_ARROW);
  cursors[1] = LoadCursor(NULL, IDC_WAIT);

  // Perform application initialization:
  mainHdl = InitInstance(hInstance, nCmdShow);
  if (!mainHdl) return FALSE;

  PIXELFORMATDESCRIPTOR pfd = { 0 };  // create the pfd
  pfd.nSize = sizeof(PIXELFORMATDESCRIPTOR);    // just its size
  pfd.nVersion = 1;   // always 1
  pfd.dwFlags = PFD_SUPPORT_OPENGL | PFD_DOUBLEBUFFER | PFD_DRAW_TO_WINDOW;
  pfd.iPixelType = PFD_TYPE_RGBA;
  pfd.cColorBits = 24;
  pfd.cDepthBits = 32;

  HDC mainDC = GetDC(mainHdl);
  int chosenPixelFormat = ChoosePixelFormat(mainDC, &pfd);
  if (!chosenPixelFormat || !SetPixelFormat(mainDC, chosenPixelFormat, &pfd)) {
    DestroyWindow(mainHdl);
    return FALSE;
  }
  hglrc = wglCreateContext(mainDC);
  wglMakeCurrent(mainDC, hglrc);
  ReleaseDC(mainHdl, mainDC);

  glDisable(GL_DEPTH_TEST);
  glEnable(GL_BLEND);
  glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
  glEnable(GL_LINE_SMOOTH);

  srand((unsigned)time(NULL));
  ShowWindow(mainHdl, nCmdShow);
  UpdateWindow(mainHdl);

  HACCEL hAccelTable = LoadAccelerators(hInstance, MAKEINTRESOURCE(IDC_OPENGLDEMO));
  MSG msg;

  // Main message loop:
  while (GetMessage(&msg, nullptr, 0, 0))
  {
    if (!TranslateAccelerator(msg.hwnd, hAccelTable, &msg))
    {
      TranslateMessage(&msg);
      DispatchMessage(&msg);
    }
  }

  //cleanup
  wglMakeCurrent(NULL, NULL);
  wglDeleteContext(hglrc);

  AnimateWindow(mainHdl, 500, AW_HIDE | AW_BLEND);
  return (int)msg.wParam;
}
//-----------------------------------------------------------------------------

ATOM MyRegisterClass(HINSTANCE hInstance)
{
    WNDCLASSEXW wcex;

    wcex.cbSize = sizeof(WNDCLASSEX);

    wcex.style          = CS_HREDRAW | CS_VREDRAW;
    wcex.lpfnWndProc    = WndProc;
    wcex.cbClsExtra     = 0;
    wcex.cbWndExtra     = 0;
    wcex.hInstance      = hInstance;
    wcex.hIcon          = LoadIcon(hInstance, MAKEINTRESOURCE(IDC_OPENGLDEMO));
    wcex.hCursor        = LoadCursor(nullptr, IDC_ARROW);
    wcex.hbrBackground  = (HBRUSH)(COLOR_WINDOW+1);
    wcex.lpszMenuName   = MAKEINTRESOURCEW(IDC_OPENGLDEMO);
    wcex.lpszClassName  = szWindowClass;
    wcex.hIconSm        = NULL;
    return RegisterClassExW(&wcex);
}
//-----------------------------------------------------------------------------

HWND InitInstance(HINSTANCE hInstance, int nCmdShow)
{
  RECT rec;
  SystemParametersInfo(SPI_GETWORKAREA, 0, &rec, 0);
  HWND hWnd = CreateWindowW(szWindowClass, szTitle, WS_OVERLAPPEDWINDOW,
    100, 100, rec.right - 200, rec.bottom -200, 
    nullptr, nullptr, hInstance, nullptr);
  return hWnd;
}
//-----------------------------------------------------------------------------

LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
  switch (message) {
    case WM_SIZE: {
      WORD clientwidth = LOWORD(lParam), clientheight = HIWORD(lParam);
      ResizingMainWnd(clientwidth, clientheight);
      break;
    }
    case WM_COMMAND: {
      int wmId = LOWORD(wParam);
      // Parse menu selections:
      switch (wmId) {
      case IDM_EXIT:
        DestroyWindow(hWnd);
        break;
      default:
        return DefWindowProc(hWnd, message, wParam, lParam);
      }
      break;
    }
    case WM_ERASEBKGND:
      return (LRESULT)1; // we'll handled it.
    case WM_PAINT: {
      PAINTSTRUCT ps;
      HDC hdc = BeginPaint(hWnd, &ps);
      RECT rec;
      GetClientRect(hWnd, &rec);
      Draw(rec.right, rec.bottom);
      SwapBuffers(hdc);
      EndPaint(hWnd, &ps);
      SetCursor(cursors[0]);
      break;
    }
    case WM_CHAR: {
      if (wParam == VK_ESCAPE) {
        PostQuitMessage(0);
        break;
      }
      else if (wParam == VK_RETURN) {
        ForceRedraw();
        break;
      }
      else return DefWindowProc(hWnd, message, wParam, lParam);
    }
    case WM_LBUTTONDOWN: {
      ForceRedraw();
      break;
    }
    case WM_DESTROY:
      PostQuitMessage(0);
      break;
    default:
      return DefWindowProc(hWnd, message, wParam, lParam);
  }
  return 0;
}
//-----------------------------------------------------------------------------

INT_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
    UNREFERENCED_PARAMETER(lParam);
    switch (message)
    {
    case WM_INITDIALOG:
    {
      //center about dialog ...
      RECT recDesktop, recDialog;
      GetWindowRect(hDlg, &recDialog);
      recDialog.right -= recDialog.left;
      recDialog.bottom -= recDialog.top;
      SystemParametersInfo(SPI_GETWORKAREA, 0, &recDesktop, 0);
      SetWindowPos(hDlg, HWND_TOP,
        (recDesktop.right - recDialog.right) >> 1,
        (recDesktop.bottom - recDialog.bottom) >> 1,
        0, 0, SWP_NOSIZE | SWP_NOREDRAW | SWP_NOACTIVATE);
      return (INT_PTR)TRUE;
    }

    case WM_COMMAND:
        if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL)
        {
            EndDialog(hDlg, LOWORD(wParam));
            return (INT_PTR)TRUE;
        }
        break;
    }
    return (INT_PTR)FALSE;
}
//-----------------------------------------------------------------------------

void ForceRedraw()
{
  SetCursor(cursors[1]);
  InvalidateRect(mainHdl, NULL, TRUE);
  UpdateWindow(mainHdl);
}
//-----------------------------------------------------------------------------

void ResizingMainWnd(int width, int height)
{
  //setup 2D projection with origin at top-left corner ...
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  glOrtho(0, width, height, 0, 0, 1);
  glViewport(0, 0, width, height);
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
}
//------------------------------------------------------------------------------

void MakeRandomPolygon(Path &path, int edge_cnt, int max_width, int max_height, int margin)
{
  max_width -= margin * 2;
  max_height -= margin * 2;
  path.resize(edge_cnt);
  for (Path::iterator iter = path.begin(); iter != path.end(); ++iter)
    (*iter) = Point64((int64_t)(rand() % (max_width)+margin),
    (int64_t)(rand() % (max_height)) + margin);
}
//------------------------------------------------------------------------------

void PathToString(Path &path, string &str) {
  ostringstream ss;
  for (Path::iterator path_it = path.begin(); path_it != path.end(); path_it++)
    ss << path_it->x << "," << path_it->y << " ";
  str = ss.str();
}
//------------------------------------------------------------------------------

void SaveToFile(const string &filename, Paths &subj, Paths &clip, ClipType ct, FillRule fr)
{
  string cliptype;
  string fillrule;
  switch (ct) {
  case ctNone: cliptype = "NONE"; break;
  case ctIntersection: cliptype = "INTERSECTION"; break;
  case ctUnion: cliptype = "UNION"; break;
  case ctDifference: cliptype = "DIFFERENCE"; break;
  case ctXor: cliptype = "XOR"; break;
  }
  switch (fr) {
  case frEvenOdd: fillrule = "EVENODD"; break;
  case frNonZero: fillrule = "NONZERO"; break;
  }

  std::ofstream file;
  file.open(filename);
  file << "CAPTION: " << cliptype << " " << fillrule << '\n';
  file << "CLIPTYPE: " << cliptype << '\n';
  file << "FILLRULE: " << fillrule << '\n';
  file << "SUBJECTS\n";
  for (Paths::iterator paths_it = subj.begin(); paths_it != subj.end(); paths_it++) {
    string s;
    PathToString(*paths_it, s);
    file << s << '\n';
  }
  file << "CLIPS\n";
  for (Paths::iterator paths_it = clip.begin(); paths_it != clip.end(); paths_it++) {
    string s;
    PathToString(*paths_it, s);
    file << s << '\n';
  }
  file.close();
}
//------------------------------------------------------------------------------

void SaveToFile(const string &filename, Paths &paths)
{
  std::ofstream file;
  file.open(filename);
  for (Paths::iterator paths_it = paths.begin(); paths_it != paths.end(); paths_it++) {
    string s;
    PathToString(*paths_it, s);
    file << s << '\n';
  }
  file.close();
}
//------------------------------------------------------------------------------

void GetPaths(stringstream &ss, Paths &paths)
{
  for (;;) { //for each path (line) ...
    Path p;
    for (;;) { //for each point
      int64_t x, y;
      char char_buf;
      int c = ss.peek();
      if (c == EOF) return;
      if (c < ' ') { //assume one or more newline chars
        ss.read(&char_buf, 1);
        break;
      }
      if (!(c == '-' || (c >= '0' && c <= '9'))) return;
      if (!(ss >> x)) return; //oops!
      c = ss.peek();
      if (c != ',') return;
      ss.read(&char_buf, 1); //gobble comma
      if (!(ss >> y)) return; //oops!
      p.push_back(Point64(x, y));
      c = ss.peek();
      if (c != ' ') break;
      ss.read(&char_buf, 1); //gobble space
    }
    if (p.size() > 2) paths.push_back(p);
    p.clear();
  }
}
//------------------------------------------------------------------------------

bool LoadFromFile(const string& filename, Paths &subj, Paths &clip, ClipType &ct, FillRule &fr)
{
  subj.clear();
  clip.clear();
  ifstream file(filename);
  if (!file.is_open()) return false;
  stringstream ss;
  ss << file.rdbuf();
  file.close();

  string line;
  bool cap_found = false;
  for (;;) {
    if (!std::getline(ss, line)) return true;
    if (!cap_found) {
      if (line.find("CAPTION: ") != std::string::npos) cap_found = true;
      continue;
    }
    if (line.find("CLIPTYPE:") != std::string::npos) {
      if (line.find("INTERSECTION") != std::string::npos) ct = ctIntersection;
      else if (line.find("UNION") != std::string::npos) ct = ctUnion;
      else if (line.find("DIFFERENCE") != std::string::npos) ct = ctDifference;
      else ct = ctXor;
    }
    else if (line.find("FILLRULE:") != std::string::npos) {
      if (line.find("EVENODD") != std::string::npos) fr = frEvenOdd;
      else fr = frNonZero;
    }
    else if (line.find("SUBJECTS") != std::string::npos) GetPaths(ss, subj);
    else if (line.find("CLIPS") != std::string::npos) GetPaths(ss, clip);
    else return true;
  }
  return true;
}
//------------------------------------------------------------------------------

inline void UnsignedToARGB(unsigned clr, uint8_t &a, uint8_t &r, uint8_t &g, uint8_t &b)
{
  a = clr >> 24; r = (clr >> 16) & 0xFF; g = (clr >> 8) & 0xFF; b = clr & 0xFF;
}
//------------------------------------------------------------------------------

void DrawPath(Paths paths, unsigned brush_color, unsigned pen_color,
  float pen_width = 1.0, bool is_open = false, FillRule fr = frEvenOdd)
{
  //first, draw the path outline ...
  uint8_t r, g, b, a;
  UnsignedToARGB(pen_color, a, r, g, b);
  if (a) {
    glLineWidth(pen_width);
    glColor4f((float)r / 255, (float)g / 255, (float)b / 255, (float)a / 255);
    for (Paths::iterator iter = paths.begin(); iter != paths.end(); ++iter) {
      if (is_open)
        glBegin(GL_LINE_STRIP);
      else
        glBegin(GL_LINE_LOOP);
      for (Path::iterator p_iter = (*iter).begin(); p_iter != (*iter).end(); ++p_iter)
        glVertex2f((float)p_iter->x, (float)p_iter->y);
      glEnd();
    }
  }
  //now fill the path (after triangulating) ...
  UnsignedToARGB(brush_color, a, r, g, b);
  if (is_open || !a) return;
  Paths triangles;
  ClipperTri clip_tri;
  clip_tri.AddPaths(paths, ptSubject);
  clip_tri.Execute(ctUnion, triangles, fr);

  glColor4f((float)r / 255, (float)g / 255, (float)b / 255, (float)a / 255);
  for (Paths::const_iterator iter = triangles.cbegin(); iter != triangles.cend(); ++iter) {
    glBegin(GL_TRIANGLES);
    for (Path::const_iterator p_iter = (*iter).begin(); p_iter != (*iter).end(); ++p_iter)
      glVertex2f((float)p_iter->x, (float)p_iter->y);
    glEnd();
  }
}
//------------------------------------------------------------------------------

void GetRcdataResource(int resourceId, stringstream &stream)
{
  HMODULE mHdl = GetModuleHandle(NULL);
  HRSRC rc = ::FindResource(mHdl, MAKEINTRESOURCE(resourceId), RT_RCDATA);
  unsigned size = ::SizeofResource(mHdl, rc);
  HGLOBAL rcData = ::LoadResource(mHdl, rc);
  CHAR *data = static_cast<CHAR*>(::LockResource(rcData));
  stream.clear();
  stream.write(data, size);
}
//------------------------------------------------------------------------------

inline DWORD GetDWORD(stringstream &stream)
{
  CHAR buf[4];
  stream.read(buf, 4);
  return *(reinterpret_cast<DWORD*>(&buf[0]));
}
//------------------------------------------------------------------------------

inline float GetFloat(stringstream &stream)
{
  CHAR buf[4];
  stream.read(buf, 4);
  return *(reinterpret_cast<float*>(&buf[0]));
}
//------------------------------------------------------------------------------

void LoadPathsFromResource(int resourceId, Paths &paths, float scale = 1.0)
{
  paths.clear();
  if (scale == 0) scale = 1;
  stringstream vals;
  unsigned dataSize = 0;
  GetRcdataResource(resourceId, vals);
  vals.seekg(0, ios_base::beg);
  unsigned cnt = GetDWORD(vals);
  paths.reserve(cnt);
  for (int i = 0; i < cnt; ++i)
  {
    int cnt2 = GetDWORD(vals);
    Path p;
    p.reserve(cnt2);
    float x, y;
    for (int j = 0; j < cnt2; ++j)
    {
      x = GetFloat(vals);
      y = GetFloat(vals);
      p.push_back(Point64(x * scale, y * scale));
    }
    if (p.size() > 2) paths.push_back(p);
  }
}
//------------------------------------------------------------------------------

void Draw(int max_width, int max_height)
{
  //fill background with a light off-gray color ...
  glClearColor(0.9f, 0.9f, 0.9f, 1.0f);
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

  Paths subj, clip, solution;
  FillRule fill_rule = frEvenOdd;
  ClipType clip_type = ctIntersection;

  ////Either ... 
  //1. Load previously saved random polygons ...
  //LoadFromFile("test.txt", subj, clip, clip_type, fill_rule);

  ////2. load polygons from the exe's resource section ...
  //LoadPathsFromResource(IDR_POLYGON, subj, 2);
  //LoadPathsFromResource(IDR_CLIP, clip, 2);

  //3. create 2 random complex (self-intersecting) polygons ...
  int edge_count = 50, margin = 30;
  subj.resize(1);
  MakeRandomPolygon(subj[0], edge_count, max_width, max_height, margin);
  clip.resize(1);
  MakeRandomPolygon(clip[0], edge_count, max_width, max_height, margin);
  SaveToFile("test.txt", subj, clip, clip_type, fill_rule);

  //intersect these polygons ...
  Clipper c;
  c.AddPaths(subj, ptSubject);
  c.AddPaths(clip, ptClip);
  c.Execute(clip_type, solution, fill_rule);

  //and then offset the solution ...
  OffsetPaths(solution, solution, -5, kRound, kPolygon);

  //aand finally draw everything ...
  DrawPath(subj, 0x100000FF, 0xFF000033, 0.6, false, fill_rule);
  DrawPath(clip, 0x22AA9900, 0xFF333300, 0.6, false, fill_rule);
  DrawPath(solution, 0x4400CC00, 0xFF006600, 1.4, false, fill_rule);
}
//------------------------------------------------------------------------------
