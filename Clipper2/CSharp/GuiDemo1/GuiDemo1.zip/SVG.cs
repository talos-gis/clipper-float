﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Web;
using System.Globalization;
using ClipperLib;

namespace SvgLib
{
  using Path = List<Point64>;
  using Paths = List<List<Point64>>;

  class SVGBuilder
  {

    public class CoordsStyle
    {
      public string FontName { get; set; }
      public int FontSize { get; set; }
      public UInt32 FontColor { get; set; }
    }

    private class PolyInfo
    {
      public Paths paths;
      public UInt32 brushClr;
      public UInt32 penClr;
      public double penWidth;
      public Boolean isOpen;
      public Boolean showCoords;
      //public int[] dashArray;
    }

    private class CaptionInfo
    {
      public string caption;
      public int fontSize;
      public UInt32 fontColor;
      public Int64 x, y;
    }

    public FillRule fillRule { get; set; }
    public CoordsStyle coordStyle = new CoordsStyle();
    private CaptionInfo captionInfo = new CaptionInfo();
    private List<PolyInfo> PolyInfoList = new List<PolyInfo>();

    //------------------------------------------------------------------------------
    //------------------------------------------------------------------------------

    public SVGBuilder()
    {
      coordStyle.FontName = "Verdana";
      coordStyle.FontSize = 10;
      coordStyle.FontColor = 0xFF000000;
    }
    //------------------------------------------------------------------------------

    public void AddCaption(string caption, string fontname,
      UInt32 fontColor, int fontSize, Int64 x, Int64 y)
    {
      captionInfo.caption = caption;
      captionInfo.fontSize = fontSize;
      captionInfo.fontColor = fontColor;
      captionInfo.x = x;
      captionInfo.y = y;
    }
    //------------------------------------------------------------------------------

    public void AddPaths(Paths paths, Boolean isOpen,
      UInt32 brushColor, UInt32 penColor, float penWidth, Boolean showCoords)
    {
      if (paths.Count == 0) return;
      PolyInfo pi = new PolyInfo();
      pi.paths = paths;
      pi.isOpen = isOpen;
      pi.brushClr = brushColor;
      pi.penClr = penColor;
      pi.penWidth = penWidth;
      pi.showCoords = showCoords;
      PolyInfoList.Add(pi);
    }
    //------------------------------------------------------------------------------

    public void AddPath(Path path, Boolean isOpen,
      UInt32 brushColor, UInt32 penColor, float penWidth, Boolean showCoords)
    {
      Paths paths = new Paths();
      paths.Add(path);
      AddPaths(paths, isOpen, brushColor, penColor, penWidth, showCoords);
    }
    //------------------------------------------------------------------------------

    static private string Color32ToHtml(UInt32 clr)
    {
      return String.Format("#{0}", (clr & 0xFFFFFF).ToString("X6"));
    }
    //------------------------------------------------------------------------------

    static private float GetAlpha(UInt32 clr)
    {
      return (float)(clr >> 24)/255;
    }
    //------------------------------------------------------------------------------

    static private string TextToHtml(string text)
    {
      return HttpUtility.HtmlEncode(text);
    }
    //------------------------------------------------------------------------------

    static private Int64 Scale (Int64 val, double scale)
    {
      return (Int64)Math.Round((double)val * scale);
    }
    //------------------------------------------------------------------------------

    public Boolean SaveToFile(string filename, int width, int height, int margin = 10)
    {
      if (filename == "" || PolyInfoList.Count == 0) return false;
      if (width < 100) width = 100;
      if (height < 100) height = 100;
      if (margin < 0) margin = 0;

      //calculate the bounding rect ...
      Rect64 rec = new Rect64(Int64.MaxValue, Int64.MaxValue, Int64.MinValue, Int64.MinValue);
      foreach (PolyInfo pi in  PolyInfoList) {
        foreach (Path path in pi.paths)
          foreach (Point64 pt in path) {
            if (pt.X < rec.left) rec.left = pt.X;
            if (pt.X > rec.right) rec.right = pt.X;
            if (pt.Y < rec.top) rec.top = pt.Y;
            if (pt.Y > rec.bottom) rec.bottom = pt.Y;
          }
      }
      if (rec.right <= rec.left || rec.bottom <= rec.top) return false;
      double scale = 
        Math.Min((double)(height - margin * 2) / (rec.bottom - rec.top), 
        (double)(width - margin * 2) / (rec.right - rec.left));

      Int64 offsetX = rec.left;
      Int64 offsetY = rec.top;

      using (StreamWriter writer = new StreamWriter(filename)) {
        writer.Write("<?xml version=\"1.0\" standalone=\"no\"?>\n" +
        "<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.0//EN\"\n" +
        "\"http://www.w3.org/TR/2001/REC-SVG-20010904/DTD/svg10.dtd\">\n\n" +
        "<svg width=\"{0}px\" height=\"{1}px\" viewBox=\"0 0 {2} {3}\" " +
        "version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\">\n\n",
            width, height, width, height);

        foreach (PolyInfo pi in PolyInfoList) {
          writer.Write(" <path d=\"");
          foreach (Path p in pi.paths) {
            if (p.Count < 3 && !pi.isOpen) continue;
            writer.Write(String.Format(NumberFormatInfo.InvariantInfo, " M {0:f2} {1:f2}",
                (double)((double)(p[0].X -offsetX) * scale + margin),
                (double)((double)(p[0].Y - offsetY) * scale + margin)));
            for (int k = 1; k < p.Count; k++) {
              writer.Write(String.Format(NumberFormatInfo.InvariantInfo, " L {0:f2} {1:f2}",
              (double)((double)(p[k].X - offsetX) * scale + margin),
              (double)((double)(p[k].Y - offsetY) * scale + margin)));
            }
            if (!pi.isOpen) writer.Write(" z");
          }

          writer.Write(String.Format(NumberFormatInfo.InvariantInfo,
            "\"\n style=\"fill:{0}; fill-opacity:{1:f2}; fill-rule:{2}; stroke:{3};" +
            " stroke-opacity:{4:f2}; stroke-width:{5:f2};\"/>\n\n",
            Color32ToHtml(pi.brushClr), GetAlpha(pi.brushClr),
            (fillRule == FillRule.EvenOdd ? "evenodd" : "nonzero"),
            Color32ToHtml(pi.penClr), GetAlpha(pi.penClr),
            pi.penWidth));

          if (pi.showCoords)
          {
            writer.Write(string.Format(
              "  <g font-family=\"{0}\" font-size=\"{1}\" fill=\"{2}\" fill-opacity=\"{3}\">\n",
              coordStyle.FontName, coordStyle.FontSize,
              Color32ToHtml(coordStyle.FontColor), GetAlpha(coordStyle.FontColor)));
            foreach (Path p in pi.paths) {
              foreach (Point64 pt in p) {
                writer.Write(String.Format(
                    "    <text x=\"{0}\" y=\"{1}\">{2},{3}</text>\n",
                    (int)((pt.X - offsetX) * scale + margin),
                    (int)((pt.Y - offsetY) * scale + margin),
                    pt.X, pt.Y));

              }
              writer.Write("\n");
            }
            writer.Write("  </g>\n\n");
          }
        }
        if (captionInfo.caption != "" && captionInfo.fontSize > 2) {
          writer.Write(string.Format("  <g font-family=\"{0}\" font-size=\"{1}\" fill=\"{2}" +
            "\" fill-opacity=\"{3}\">\n    <text x=\"{4}\" y=\"{5}\">{6}</text>\n  </g>\n\n",
            coordStyle.FontName, captionInfo.fontSize,
            Color32ToHtml(captionInfo.fontColor), GetAlpha(captionInfo.fontColor),
            captionInfo.x, captionInfo.y, TextToHtml(captionInfo.caption)));
        }

        writer.Write("</svg>\n");
      }
      return true;
    } //FileSave
    //------------------------------------------------------------------------------

  } //class SVGBuilder
} //end namespace