//#define UsePolyTree

using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Windows.Forms;
using System.IO;

using ClipperLib;
using SvgLib;

namespace WindowsFormsApplication1
{
  using Path = List<Point64>;
  using Paths = List<List<Point64>>;

  public partial class Form1 : Form
  {
    private Bitmap mainBmp;
    private Paths subjects = new Paths();
    private Paths clips = new Paths();
    private Paths solution = new Paths();
    private int MaxColors = 13;
    private UInt32[] colors; 
    //Here we are scaling all coordinates up by 10 when they're passed to Clipper 
    //via Path (or Paths) objects because Clipper doesn't accepts floating point values. 
    //Likewise when Clipper returns a solution in a Paths object. We'll also need to 
    //scale down these values before displaying.
    private float scale = 1;

    //---------------------------------------------------------------------

    UInt32 GradientColor(UInt32 color1, UInt32 color2, float frac)
    {
      if (frac >= 1) return color2;
      else if (frac <= 0) return color1;
      byte b1, g1, r1, b2, g2, r2;
      b1 = (byte)((color1 >> 16) & 0xFF);
      g1 = (byte)((color1 >> 8) & 0xFF);
      r1 = (byte)(color1 & 0xFF);
      b2 = (byte)((color2 >> 16) & 0xFF);
      g2 = (byte)((color2 >> 8) & 0xFF);
      r2 = (byte)(color2 & 0xFF);
      float OneMinFrac = 1 - frac;
      b1 = (byte)((float)b1 * (OneMinFrac) + (float)b2 * frac);
      g1 = (byte)((float)g1 * (OneMinFrac) + (float)g2 * frac);
      r1 = (byte)((float)r1 * (OneMinFrac) + (float)r2 * frac);
      return (UInt32)((b1 << 16) | (g1 << 8) | r1);
    }
    //------------------------------------------------------------------------------

    UInt32 GradientRainbowColor(float fraction, byte alpha)
    {
      UInt32[] colors = { 0xFF0000, 0xFFFF00, 0x00FF00, 0x00FFFF, 0x0000FF, 0xFF00FF };
      if (fraction >= 1 || fraction <= 0) return (UInt32)(colors[0] | (UInt32)(alpha << 24));
      fraction *= 6;
      int f = (int)fraction;
      return GradientColor(colors[f], colors[(f + 1) % 6], fraction - f) | (UInt32)(alpha << 24);
    }
    //------------------------------------------------------------------------------

    void UInt32ColorToARGB(UInt32 color, out int a, out int r, out int g, out int b)
    {
      a = (int)(color >> 24);
      r = (int)((color >> 16) & 0xFF);
      g = (int)((color >> 8) & 0xFF);
      b = (int)(color & 0xFF);
    }
    //------------------------------------------------------------------------------

    Boolean StringToPath(string s, Path p)
    {
      string[] vals = s.Split(new Char[] {' ', ','});
      p.Clear();
      p.Capacity = vals.Length >> 1;
      Int64 x = 0, y = 0;
      Boolean hasX = false;
      foreach (string val in vals)
      {
        if (!hasX)
        {
          hasX = Int64.TryParse(val, out x);
          if (!hasX) break;
          continue;
        }
        else if (!Int64.TryParse(val, out y))
          break;
        p.Add(new Point64(x, y));
        hasX = false;
      }
      return p.Count > 0;
    }
    //------------------------------------------------------------------------------

    void SaveToFile(string filename, string caption, Paths subj, Paths clip, ClipType ct, FillRule fr)
    {
      using (StreamWriter writer = new StreamWriter(filename))
      {
        writer.Write("CAPTION: {0}\n", caption);
        writer.Write("CLIPTYPE: {0}\n", ct.ToString().ToUpper());
        writer.Write("FILLRULE: {0}\n", fr.ToString().ToUpper());
        if (subj.Count > 0)
        {
          writer.Write("SUBJECTS\n");
          foreach (Path p in subj)
          {
            foreach (Point64 pt in p) writer.Write("{0},{1} ", pt.X, pt.Y);
            writer.Write("\n");
          }
        }
        if (clip.Count > 0)
        {
          writer.Write("CLIPS\n");
          foreach (Path p in clip)
          {
            foreach (Point64 pt in p) writer.Write("{0},{1} ", pt.X, pt.Y);
            writer.Write("\n");
          }
        }
      }
    }
    //------------------------------------------------------------------------------

    void LoadFromFile(string filename, ref Paths subj, ref Paths clip, ref ClipType ct, ref FillRule fr)
    {
      subj.Clear(); clip.Clear();
      using (StreamReader reader = new StreamReader(filename))
      {
        string line;
        Boolean hasCaption = false;
        bool gettingSubj = true;
        while ((line = reader.ReadLine()) != null)
        {
          if (line.Length == 0) continue;
          else if (line.IndexOf("CAPTION:") == 0)
          {
            if (hasCaption) break; //allows for multiple tests in same file (todo: use idx later)
            hasCaption = true;
            //line = line.Remove(0, 8);
          }
          else if (line.IndexOf("CLIPTYPE:") == 0)
          {
            line = line.Remove(0, 9).Trim().ToUpper();
            if (line == null) break;
            switch (line[0])
            {
              case 'I': ct = ClipType.Intersection; break;
              case 'U': ct = ClipType.Union; break;
              case 'D': ct = ClipType.Difference; break;
              case 'X': ct = ClipType.Xor; break;
              default: ct = ClipType.None; break;
            }
          }
          else if (line.IndexOf("FILLRULE:") == 0)
          {
            line = line.Remove(0, 9).Trim().ToUpper();
            if (line == null) break;
            switch (line[0])
            {
              case 'E': fr = FillRule.EvenOdd; break;
              case 'P': fr = FillRule.Positive; break;
              case 'N': fr = (line[1] == 'O') ? FillRule.NonZero : FillRule.Negative; break;
            }
          }
          else if (line.IndexOf("SUBJ") == 0) { if (subj.Count > 0) break; }
          else if (line.IndexOf("CLIPS") == 0) { gettingSubj = false; }
          else
          {
            Path p = new Path();
            if (!StringToPath(line, p)) break;
            if (gettingSubj) subj.Add(p); else clip.Add(p);
          }
        }//while
      }//using
    }
    //------------------------------------------------------------------------------

    static private PointF[] PolygonToPointFArray(Path pg, float scale)
    {
      PointF[] result = new PointF[pg.Count];
      for (int i = 0; i < pg.Count; ++i)
      {
        result[i].X = (float)pg[i].X / scale;
        result[i].Y = (float)pg[i].Y / scale;
      }
      return result;
    }
    //---------------------------------------------------------------------

    public Form1()
    {
      InitializeComponent();
      this.MouseWheel += new MouseEventHandler(Form1_MouseWheel);
      mainBmp = new Bitmap(
        pictureBox1.ClientRectangle.Width,
        pictureBox1.ClientRectangle.Height,
        PixelFormat.Format32bppArgb);
    }
    //---------------------------------------------------------------------

    private void Form1_MouseWheel(object sender, MouseEventArgs e)
    {
      if (e.Delta > 0 && nudOffset.Value < 10) nudOffset.Value += (decimal)0.5;
      else if (e.Delta < 0 && nudOffset.Value > -10) nudOffset.Value -= (decimal)0.5;
    }
    //---------------------------------------------------------------------

    private void bRefresh_Click(object sender, EventArgs e)
    {
      DrawBitmap();
    }
    //---------------------------------------------------------------------

    private Point64 GenerateRandomPoint(int l, int t, int r, int b, Random rand)
    {
      int Q = 10; //for rounding to nearest 10
      return new Point64(
        Convert.ToInt64((rand.Next(r / Q) * Q + l + 10) * scale),
        Convert.ToInt64((rand.Next(b / Q) * Q + t + 10) * scale));
    }
    //---------------------------------------------------------------------

    private void GenerateRandomPolygon(int count)
    {
      int Q = 10;
      Random rand = new Random();
      int r = (pictureBox1.ClientRectangle.Width - 20) / Q * Q;
      int b = (pictureBox1.ClientRectangle.Height - 20) / Q * Q;

      ////1. either load previously saved polygons 
      //ClipType ct = ClipType.Intersection;
      //FillRule fr = FillRule.EvenOdd;
      //LoadFromFile("..\\..\\test.txt", ref subjects, ref clips, ref ct, ref fr);

      //2. or generated new random polygons ...
      subjects.Clear();
      clips.Clear();
      int l = 10; int t = 10;
      Path subj = new Path(count);
      for (int i = 0; i < count; ++i)
        subj.Add(GenerateRandomPoint(l, t, r, b, rand));
      subjects.Add(subj);

      Path clip = new Path(count);
      for (int i = 0; i < count; ++i)
        clip.Add(GenerateRandomPoint(l, t, r, b, rand));
      clips.Add(clip);
      //and save to file (eg may be useful for debugging) 
      SaveToFile("..\\..\\test.txt", "", subjects, clips, GetClipType(), GetFillRule());
    }
    //---------------------------------------------------------------------

    ClipType GetClipType()
    {
      if (rbIntersect.Checked) return ClipType.Intersection;
      if (rbUnion.Checked) return ClipType.Union;
      if (rbDifference.Checked) return ClipType.Difference;
      else return ClipType.Xor;
    }
    //---------------------------------------------------------------------

    FillRule GetFillRule()
    {
      if (rbNonZero.Checked) return FillRule.NonZero;
      else return FillRule.EvenOdd;
    }
    //---------------------------------------------------------------------

    private void DrawBitmap(bool justClip = false)
    {
      Cursor.Current = Cursors.WaitCursor;
      try {
        if (!justClip) GenerateRandomPolygon((int)nudCount.Value);

        using (Graphics graphic = Graphics.FromImage(mainBmp))
        using (GraphicsPath gpath = new GraphicsPath()) {
          graphic.SmoothingMode = SmoothingMode.AntiAlias;
          graphic.Clear(Color.White);
          if (rbNonZero.Checked)
            gpath.FillMode = FillMode.Winding;

          using (Pen myPen = new Pen(Color.FromArgb(196, 0xC3, 0xC9, 0xCF), (float)0.6))
          using (SolidBrush myBrush = new SolidBrush(Color.FromArgb(127, 0xDD, 0xDD, 0xF0))) {

            //draw subjects ...
            foreach (Path p in subjects) {
              PointF[] pts = PolygonToPointFArray(p, scale);
              gpath.AddPolygon(pts);
              pts = null;
            }
            graphic.FillPath(myBrush, gpath);
            graphic.DrawPath(myPen, gpath);
            gpath.Reset();

            //draw clips ...
            if (rbNonZero.Checked) gpath.FillMode = FillMode.Winding;
            foreach (Path p in clips) {
              PointF[] pts = PolygonToPointFArray(p, scale);
              gpath.AddPolygon(pts);
              pts = null;
            }
            myPen.Color = Color.FromArgb(196, 0xF9, 0xBE, 0xA6);
            myBrush.Color = Color.FromArgb(127, 0xFF, 0xE0, 0xE0);
            graphic.FillPath(myBrush, gpath);
            graphic.DrawPath(myPen, gpath);
            gpath.Reset();

            //do the clipping ...
            if ((clips.Count > 0 || subjects.Count > 0) && !rbNone.Checked)
            {
              Paths solution2 = new Paths();

              Clipper c;
              if (cbTriangulate.Checked) c = new ClipperTri();
              else c = new Clipper();

              c.AddPaths(subjects, PathType.Subject);
              c.AddPaths(clips, PathType.Clip);
              solution.Clear();
              c.Execute(GetClipType(), solution, GetFillRule());
              //SaveToFile("solution", solution);
              myBrush.Color = Color.Black;
              gpath.Reset();

              //It really shouldn't matter what FillMode is used for solution
              //polygons because none of the solution polygons overlap. 
              //However, FillMode.Winding will show any orientation errors where 
              //holes will be stroked (outlined) correctly but filled incorrectly  ...
              gpath.FillMode = FillMode.Winding;

              //and polygon offsetting ...
              if (nudOffset.Value != 0 && !cbTriangulate.Checked)
              {
                ClipperOffset co = new ClipperOffset();
                co.AddPaths(solution, JoinType.Round, EndType.Polygon);
                co.Execute(ref solution2, (double)nudOffset.Value * scale);
              }
              else
                solution2 = new Paths(solution);

              myPen.Width = 1.0f;
              if (cbTriangulate.Checked)
              {
                int idx = 0, a, r, g, b;
                myPen.Color = Color.FromArgb(0x60, 0x33, 0x33, 0x33);
                foreach (Path p in solution2)
                {
                  UInt32ColorToARGB(colors[idx++ % MaxColors], out a, out r, out g, out b);
                  myBrush.Color = Color.FromArgb(a, r, g, b);
                  PointF[] pts = PolygonToPointFArray(p, scale);
                  gpath.AddPolygon(pts);
                  graphic.FillPath(myBrush, gpath);
                  graphic.DrawPath(myPen, gpath);
                  gpath.Reset();
                  pts = null;
                }
              }
              else
              {
                myBrush.Color = Color.FromArgb(127, 0x66, 0xEF, 0x7F);
                myPen.Color = Color.FromArgb(255, 0, 0x33, 0);
                foreach (Path p in solution2)
                {
                  PointF[] pts = PolygonToPointFArray(p, scale);
                  if (pts.Length > 2) gpath.AddPolygon(pts);
                  pts = null;
                }
                graphic.FillPath(myBrush, gpath);
                graphic.DrawPath(myPen, gpath);
              }
            } 
            pictureBox1.Image = mainBmp;
          }
        }
      }
      finally
      {
        Cursor.Current = Cursors.Default;
      }
    }
    //---------------------------------------------------------------------

    private void Form1_Load(object sender, EventArgs e)
    {
      toolStripStatusLabel1.Text =
          "Tip: Use the mouse-wheel (or +,-,0) to adjust the offset of the solution polygons.";
      colors = new UInt32[MaxColors];
      for (int i = 0; i < MaxColors; i++)
        colors[i] = GradientRainbowColor((float)(i) / MaxColors, 0xff);
      Form1_Resize(sender, e);
    }
    //---------------------------------------------------------------------

    private void bClose_Click(object sender, EventArgs e)
    {
      Close();
    }
    //---------------------------------------------------------------------

    private void Form1_Resize(object sender, EventArgs e)
    {
      if (pictureBox1.ClientRectangle.Width == 0 ||
          pictureBox1.ClientRectangle.Height == 0) return;
      if (mainBmp != null) mainBmp.Dispose();
      mainBmp = new Bitmap(
          pictureBox1.ClientRectangle.Width,
          pictureBox1.ClientRectangle.Height,
          PixelFormat.Format32bppArgb);
      pictureBox1.Image = mainBmp;
      DrawBitmap();
    }
    //---------------------------------------------------------------------

    private void rbNonZero_Click(object sender, EventArgs e)
    {
      DrawBitmap(true);
    }
    //---------------------------------------------------------------------

    private void cbTriangulate_Click(object sender, EventArgs e)
    {
      if (cbTriangulate.Checked) nudOffset.Value = 0;
      DrawBitmap(true);
    }
    //---------------------------------------------------------------------

    private void Form1_KeyDown(object sender, KeyEventArgs e)
    {
      switch (e.KeyCode)
      {
        case Keys.Escape:
          this.Close();
          return;
        case Keys.F1:
          MessageBox.Show(this.Text + "\nby Angus Johnson\nCopyright © 2010 - 2017",
          this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
          e.Handled = true;
          return;
        case Keys.Oemplus:
        case Keys.Add:
          if (nudOffset.Value == 10) return;
          nudOffset.Value += (decimal)0.5;
          e.Handled = true;
          break;
        case Keys.OemMinus:
        case Keys.Subtract:
          if (nudOffset.Value == -10) return;
          nudOffset.Value -= (decimal)0.5;
          e.Handled = true;
          break;
        case Keys.NumPad0:
        case Keys.D0:
          if (nudOffset.Value == 0) return;
          nudOffset.Value = (decimal)0;
          e.Handled = true;
          break;
        default: return;
      }

    }
    //---------------------------------------------------------------------

    private void nudCount_ValueChanged(object sender, EventArgs e)
    {
      DrawBitmap(true);
    }
    //---------------------------------------------------------------------

    private void bSave_Click(object sender, EventArgs e)
    {
      //save to SVG ...
      if (saveFileDialog1.ShowDialog() == DialogResult.OK)
      {
        SVGBuilder svg = new SVGBuilder();
        svg.fillRule = GetFillRule();
        svg.AddCaption("Clipper demo", "Verdana", 0xFF000000, 14, 20, 20);
        svg.AddPaths(subjects, false, 0x200000FF, 0xFF000066, 0.6f, false);
        svg.AddPaths(clips, false, 0x20CCCC00, 0xFF666600, 0.6f, false);
        svg.AddPaths(solution, false, 0x6600CC00, 0xFF003300, 1.0f, true);
        svg.SaveToFile(saveFileDialog1.FileName, 1200, 800, 60);
      }
    }
    //---------------------------------------------------------------------

  }
}
