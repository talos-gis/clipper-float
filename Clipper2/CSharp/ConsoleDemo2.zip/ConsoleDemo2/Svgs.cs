﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Globalization;
using System.Diagnostics;
using ClipperLib;

namespace SVG
{

  using cInt = Int64;
  using Path = List<Point64>;
  using Paths = List<List<Point64>>;

  //a simple class to build SVG files that display Paths ...
  class SVGBuilder
  {

    public static Rect64 irMax = new Rect64(cInt.MaxValue, cInt.MaxValue, -cInt.MaxValue, -cInt.MaxValue);

    public class StyleInfo
    {
      public FillType fillType;
      public Color brushClr;
      public Color penClr;
      public double penWidth;
      public int[] dashArray;
      public bool showCoords;
      public bool closePath;
      public StyleInfo()
      {
        penWidth = 0.8;
        closePath = true;
      }

      public StyleInfo Clone()
      {
        StyleInfo result = new StyleInfo();
        result.fillType = fillType;
        result.brushClr = brushClr;
        result.penClr = penClr;
        result.penWidth = penWidth;
        result.dashArray = dashArray;
        result.showCoords = showCoords;
        result.closePath = closePath;
        return result;
      }
    }

    public class PolyInfo
    {
      public Paths Paths = new Paths();
      public StyleInfo si;
    }

    public StyleInfo style;
    private List<PolyInfo> PolyInfoList;
    private Rect64 bounds;
    const string svg_header = "<?xml version=\"1.0\" standalone=\"no\"?>\n" +
      "<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.0//EN\"\n" +
      "\"http://www.w3.org/TR/2001/REC-SVG-20010904/DTD/svg10.dtd\">\n\n" +
      "<svg width=\"{0}px\" height=\"{1}px\" viewBox=\"0 0 {2} {3}\" " +
      "version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\">\n\n";
    const string svg_path_format = "\"\n style=\"fill:{0};" +
        " fill-opacity:{1:f2}; fill-rule:{2}; stroke:{3};" +
        "{6} stroke-opacity:{4:f2}; stroke-width:{5:f2};\"/>\n\n";
    const string svg_path_format2 = "\"\n style=\"fill:none; stroke:{0};" +
        "stroke-opacity:{1:f2}; stroke-width:{2:f2};\"/>\n\n";

    public SVGBuilder()
    {
      PolyInfoList = new List<PolyInfo>();
      style = new StyleInfo();
      bounds = irMax;
    }

    public double PenWidth { get { return style.penWidth; } set { style.penWidth = value; } }

    public void AddPath(Path poly, UInt32 brushColor, UInt32 penColor, Boolean closed)
    {
      AddPath(poly, Color.FromArgb(unchecked((int)brushColor)), Color.FromArgb(unchecked((int)penColor)), closed);
    }

    public void AddPath(Path poly, Color brushColor, Color penColor, Boolean closed)
    {
      //add a single Path per PolyInfo struct
      if (poly.Count == 0) return;
      PolyInfo pi = new PolyInfo();
      pi.si = style.Clone();
      pi.Paths.Add(poly);
      pi.si.brushClr = brushColor;
      pi.si.penClr = penColor;
      pi.si.closePath = closed;
      PolyInfoList.Add(pi);
    }

    private void UpdateBounds(Paths polys)
    {
      for (int i = 0; i < polys.Count; i++)
        for (int j = 0; j < polys[i].Count; i++)
        {
          if (polys[i][j].X < bounds.left) bounds.left = polys[i][j].X;
          if (polys[i][j].X > bounds.right) bounds.right = polys[i][j].X;
          if (polys[i][j].Y < bounds.top) bounds.top = polys[i][j].Y;
          if (polys[i][j].Y < bounds.bottom) bounds.bottom = polys[i][j].Y;
        }
    }

    public void AddPaths(Paths polys, UInt32 brushColor, UInt32 penColor, Boolean closed)
    {
      AddPaths(polys, Color.FromArgb(unchecked((int)brushColor)), Color.FromArgb(unchecked((int)penColor)), closed);
    }

    public void AddPaths(Paths polys, Color brushColor, Color penColor, Boolean closed)
    {
      //add multiple Paths per PolyInfo struct
      PolyInfo pi = new PolyInfo();
      pi.si = style.Clone();
      foreach (Path p in polys)
        pi.Paths.Add(p);
      pi.si.brushClr = brushColor;
      pi.si.penClr = penColor;
      pi.si.closePath = closed;
      PolyInfoList.Add(pi);
    }

    //public void AddPolyTree(PolyTree polytree, Color brushColor, Color penColor)
    //{
    //  //add all Paths (outers and holes)...
    //  PolyInfo pi = new PolyInfo();
    //  pi.si = style.Clone();
    //  PolyNode node = polytree.GetFirst();
    //  while (node != null)
    //  {
    //    pi.Paths.Add(node.Contour);
    //    node = node.GetNext();
    //  }
    //  pi.si.brushClr = brushColor;
    //  pi.si.penClr = penColor;
    //  pi.si.closePath = true;
    //  PolyInfoList.Add(pi);

    //  pi = new PolyInfo();
    //  pi.si = style.Clone();
    //  node = polytree.GetFirst();
    //  while (node != null)
    //  {
    //    if (node.IsHole)
    //      pi.Paths.Add(node.Contour);
    //    node = node.GetNext();
    //  }
    //  pi.si.brushClr = Color.FromArgb(0, 0, 0, 0);
    //  pi.si.penClr = Color.Red;
    //  pi.si.penWidth = 0.4;
    //  pi.si.fillType = style.fillType;
    //  pi.si.dashArray = style.dashArray;
    //  PolyInfoList.Add(pi);
    //}

    public Boolean SaveToFile(string filename, int width = 0, int height = 0, int margin = 10)
    {
      if (margin < 0) margin = 0;
      //calculate the bounding rect ...
      Rect64 rec = irMax;
      foreach (PolyInfo pi in PolyInfoList)
        foreach (Path pg in pi.Paths)
          foreach (Point64 pt in pg)
          {
            if (pt.X < rec.left) rec.left = pt.X;
            if (pt.X > rec.right) rec.right = pt.X;
            if (pt.Y < rec.top) rec.top = pt.Y;
            if (pt.Y > rec.bottom) rec.bottom = pt.Y;
          }

      if (rec.left > rec.right) return false;

      double scale = 1.0;
      if (width > 0 && height > 0)
        scale = 1.0 / Math.Max((double)(rec.right - rec.left) / (width - margin * 2),
          (double)(rec.bottom - rec.top) / (height - margin * 2));

      cInt offsetX = margin - (cInt)((double)rec.left * scale);
      cInt offsetY = margin - (cInt)((double)rec.top * scale);

      StreamWriter writer = new StreamWriter(filename);
      if (writer == null) return false;
      writer.Write(svg_header, width, height, width, height);

      foreach (PolyInfo pi in PolyInfoList)
      {
        writer.Write(" <path d=\"");
        foreach (Path p in pi.Paths)
        {
          if ((pi.si.closePath && p.Count < 3) || (!pi.si.closePath && p.Count < 2)) continue;
          writer.Write(string.Format(NumberFormatInfo.InvariantInfo, " M {0:f2} {1:f2}",
              (double)((double)p[0].X * scale + offsetX),
              (double)((double)p[0].Y * scale + offsetY)));
          for (int k = 1; k < p.Count; k++)
          {
            writer.Write(string.Format(NumberFormatInfo.InvariantInfo, " L {0:f2} {1:f2}",
            (double)((double)p[k].X * scale + offsetX),
            (double)((double)p[k].Y * scale + offsetY)));
          }
          if (pi.si.closePath) writer.Write(" z");
        }

        string dashString;
        if (pi.si.dashArray != null)
        {
          dashString = " stroke-dasharray: " + pi.si.dashArray[0];
          for (int k = 1; k < pi.si.dashArray.Count(); k++)
            dashString += ", " + pi.si.dashArray[k];
          dashString += ";";
        }

        else
          dashString = "";

        if (pi.si.closePath)
          writer.Write(string.Format(NumberFormatInfo.InvariantInfo, svg_path_format,
              ColorTranslator.ToHtml(pi.si.brushClr),
              (float)pi.si.brushClr.A / 255,
              (pi.si.fillType == FillType.EvenOdd ? "evenodd" : "nonzero"),
              ColorTranslator.ToHtml(pi.si.penClr),
              (float)pi.si.penClr.A / 255,
              pi.si.penWidth,
              dashString));
        else
          writer.Write(string.Format(NumberFormatInfo.InvariantInfo, svg_path_format2,
              ColorTranslator.ToHtml(pi.si.penClr),
              (float)pi.si.penClr.A / 255,
              pi.si.penWidth
              ));

        if (pi.si.showCoords)
        {
          writer.Write("<g font-family=\"Verdana\" font-size=\"11\" fill=\"black\">\n\n");
          foreach (Path p in pi.Paths)
          {
            foreach (Point64 pt in p)
            {
              Int64 x = pt.X;
              Int64 y = pt.Y;
              writer.Write(string.Format(
                  "<text x=\"{0}\" y=\"{1}\">{2},{3}</text>\n",
                  (int)(x * scale + offsetX), (int)(y * scale + offsetY), x, y));

            }
            writer.Write("\n");
          }
          writer.Write("</g>\n");
        }
      }
      writer.Write("</svg>\n");
      writer.Close();
      return true;
    }
  } //ends SVGBuilder class

}
