﻿/*******************************************************************************
*                                                                              *
* Author    :  Angus Johnson                                                   *
* Date      :  14 September 2017                                               *
* Website   :  http://www.angusj.com                                           *
* Copyright :  Angus Johnson 2010-2017                                         *
*                                                                              *
* License:                                                                     *
* Use, modification & distribution is subject to Boost Software License Ver 1. *
* http://www.boost.org/LICENSE_1_0.txt                                         *
*                                                                              *
*******************************************************************************/

using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using ClipperLib;
using SVG;

namespace Clipper2Demo
{
  using Path = List<Point64>;
  using Paths = List<List<Point64>>;
  
  class Application
  {

    //-----------------------------------------------------------------------
    //-----------------------------------------------------------------------

    static Path PathFromStr(string s)
    {
      if (s == null) return null;
      Path p = new Path();
      int len = s.Length, i = 0, j;
      while (i < len)
      {
        Int64 y, x;
        bool isNeg;
        while ((int)s[i] < 33 && i < len) i++;
        if (i >= len) break;
        //get X ...
        isNeg = (int)s[i] == 45;
        if (isNeg) i++;
        if (i >= len || (int)s[i] < 48 || (int)s[i] > 57) break;
        j = i + 1;
        while (j < len && (int)s[j] > 47 && (int)s[j] < 58) j++;
        if (!Int64.TryParse(s.Substring(i, j - i), out x)) break;
        if (isNeg) x = -x;
        //skip space or comma between X & Y ...
        i = j;
        while (i < len && ((int)s[i] == 32 || (int)s[i] == 44)) i++;
        //get Y ...
        if (i >= len) break;
        isNeg = (int)s[i] == 45;
        if (isNeg) i++;
        if (i >= len || (int)s[i] < 48 || (int)s[i] > 57) break;
        j = i + 1;
        while (j < len && (int)s[j] > 47 && (int)s[j] < 58) j++;
        if (!Int64.TryParse(s.Substring(i, j - i), out y)) break;
        if (isNeg) y = -y;
        p.Add(new Point64(x, y));
        //skip trailing space, comma ...
        i = j;
        while (i < len && ((int)s[i] == 32 || (int)s[i] == 44)) i++;
      }
      return p;
    }
    //------------------------------------------------------------------------------

    static Paths PathsFromStr(string s)
    {
      if (s == null) return null;
      Path p = new Path();
      Paths pp = new Paths();
      int len = s.Length, i = 0, j;
      while (i < len)
      {
        Int64 y, x;
        bool isNeg;
        while ((int)s[i] < 33 && i < len) i++;
        if (i >= len) break;
        //get X ...
        isNeg = (int)s[i] == 45;
        if (isNeg) i++;
        if (i >= len || (int)s[i] < 48 || (int)s[i] > 57) break;
        j = i + 1;
        while (j < len && (int)s[j] > 47 && (int)s[j] < 58) j++;
        if (!Int64.TryParse(s.Substring(i, j - i), out x)) break;
        if (isNeg) x = -x;
        //skip space or comma between X & Y ...
        i = j;
        while (i < len && ((int)s[i] == 32 || (int)s[i] == 44)) i++;
        //get Y ...
        if (i >= len) break;
        isNeg = (int)s[i] == 45;
        if (isNeg) i++;
        if (i >= len || (int)s[i] < 48 || (int)s[i] > 57) break;
        j = i + 1;
        while (j < len && (int)s[j] > 47 && (int)s[j] < 58) j++;
        if (!Int64.TryParse(s.Substring(i, j - i), out y)) break;
        if (isNeg) y = -y;
        p.Add(new Point64(x, y));
        //skip trailing space, comma ...
        i = j;
        int nlCnt = 0;
        while (i < len && ((int)s[i] < 33 || (int)s[i] == 44))
        {
          if (i >= len) break;
          if ((int)s[i] == 10)
          {
            nlCnt++;
            if (nlCnt == 2)
            {
              if (p.Count > 2) pp.Add(p);
              p = new Path();
            }
          }
          i++;
        }
      }
      if (p.Count > 2) pp.Add(p);
      return pp;
    }
    //------------------------------------------------------------------------------

    static bool LoadTestNum(string filename, int num, 
      Paths subj, Paths subj_open, Paths clip, out ClipType ct, out FillType ft)
    {
      if (subj == null) subj = new Paths(); else subj.Clear();
      if (subj_open == null) subj_open = new Paths(); else subj_open.Clear();
      if (clip == null) clip = new Paths(); else clip.Clear();
      ct = ClipType.Intersection;
      ft = FillType.EvenOdd;
      bool numFound = false, result = false;
      int GetIdx = 0;
      string numstr = num.ToString();
      StreamReader reader = new StreamReader(filename);
      if (reader == null) return false;
      while (true)
      {
        string s = reader.ReadLine();
        if (s == null) break;

        if (s.IndexOf("CAPTION: ") == 0)
        {
          numFound = (s.IndexOf(numstr) > 0);
          if (numFound) result = true;
          continue;
        }

        if (!numFound) continue;

        if (s.IndexOf("CLIPTYPE: ") == 0)
        {
          if (s.IndexOf("INTERSECTION") > 0) ct = ClipType.Intersection;
          else if (s.IndexOf("UNION") > 0) ct = ClipType.Union;
          else if (s.IndexOf("INTERSECTION") > 0) ct = ClipType.Difference;
          else ct = ClipType.Xor;
          continue;
        }

        if (s.IndexOf("FILLTYPE: ") == 0)
        {
          if (s.IndexOf("EVENODD") > 0) ft = FillType.EvenOdd;
          else ft = FillType.NonZero;
          continue;
        }

        if (s.IndexOf("SUBJECTS_OPEN") == 0) GetIdx = 2;
        else if (s.IndexOf("SUBJECTS") == 0) GetIdx = 1;
        else if (s.IndexOf("CLIPS") == 0) GetIdx = 3;
        else continue;

        while (true)
        {
          s = reader.ReadLine();
          Path p = PathFromStr(s);
          if (p == null || p.Count == 0)
          {
            if (GetIdx == 3) return result;
            else if (s.IndexOf("SUBJECTS_OPEN") == 0) GetIdx = 2;
            else if (s.IndexOf("CLIPS") == 0) GetIdx = 3;
            else return result;
            continue;
          }
          if (GetIdx == 1) subj.Add(p);
          else if (GetIdx == 2) subj_open.Add(p);
          else clip.Add(p);
        }
      }
      return result;
    }
    //-----------------------------------------------------------------------

    public static void SaveToFile(string filename, Paths subj, Paths subj_open, Paths clip, ClipType ct, FillType ft)
    {
      StreamWriter writer = new StreamWriter(filename);
      if (writer == null) return;
      writer.Write("CAPTION: 1. \r\n");
      writer.Write("CLIPTYPE: {0}\r\n", ct.ToString().ToUpper());
      writer.Write("FILLTYPE: {0}\r\n", ft.ToString().ToUpper());
      if (subj != null && subj.Count > 0)
      {
        writer.Write("SUBJECTS\r\n");
        foreach (Path p in subj)
        {
          foreach (Point64 ip in p)
            writer.Write("{0},{1} ", ip.X, ip.Y);
          writer.Write("\r\n");
        }
      }
      if (subj_open != null && subj_open.Count > 0)
      {
        writer.Write("SUBJECTS_OPEN\r\n");
        foreach (Path p in subj_open)
        {
          foreach (Point64 ip in p)
            writer.Write("{0},{1} ", ip.X, ip.Y);
          writer.Write("\r\n");
        }
      }
      if (clip != null && clip.Count > 0)
      {
        writer.Write("CLIPS\r\n");
        foreach (Path p in clip)
        {
          foreach (Point64 ip in p)
            writer.Write("{0},{1} ", ip.X, ip.Y);
          writer.Write("\r\n");
        }
      }
      writer.Close();
    }
    //-----------------------------------------------------------------------

    private static Point64 MakeRandomPt(int maxWidth, int maxHeight, int rndTo, Random rand)
    {
      Point64 pt = new Point64();
      pt.X = (Int64)(rand.Next(maxWidth / rndTo) * rndTo);
      pt.Y = (Int64)(rand.Next(maxHeight / rndTo) * rndTo);
      return pt;
    }
    //---------------------------------------------------------------------

    public static Path MakeRandomPath(int width, int height, int count, Random rand)
    {
      int roundTo = 10;
      rand.Next();
      Path result = new Path(count);
      for (int i = 0; i < count; ++i)
        result.Add(MakeRandomPt(width, height, roundTo, rand));
      return result;
    }
    //---------------------------------------------------------------------

    public static Paths LoadPathsFromResource(string resourceName, double scaleBy = 1)
    {
      using (Stream stream = Assembly.GetExecutingAssembly().GetManifestResourceStream(resourceName))
      using (BinaryReader reader = new BinaryReader(stream))
      {
        int len = reader.ReadInt32();
        Paths result = new Paths(len);
        for (int i = 0; i < len; i++)
        {
          int len2 = reader.ReadInt32();
          Path p = new Path(len2);
          for (int j = 0; j < len2; j++)
          {
            float x = reader.ReadSingle();
            float y = reader.ReadSingle();
            p.Add(new Point64(x * scaleBy, y * scaleBy));
          }
          result.Add(p);
        }
        return result;
      }
    }
    //-----------------------------------------------------------------------

    public static Paths AffineTranslatePaths(Paths paths, Int64 dx, Int64 dy)
    {
      Paths result = new Paths(paths.Count);
      foreach (Path path in paths)
      {
        Path p = new Path(path.Count);
        foreach (Point64 pt in path)
          p.Add(new Point64(pt.X + dx, pt.Y + dy));
        result.Add(p);
      }
      return result;
    }
    //-----------------------------------------------------------------------

    public static void Main(string[] args)
    {

      Paths subj = new Paths();
      Paths subj_open = new Paths();
      Paths clip = new Paths();
      Paths sol = new Paths();
      Paths sol_open = new Paths();
      ClipType ct = ClipType.Intersection;
      FillType ft = FillType.EvenOdd;
      int displayWidth = 1024, displayHeight = 768, border = 100;

      /////////////////////////////////////////////////////////////////////////
      // LOAD SIMPLE ...
      /////////////////////////////////////////////////////////////////////////

      ////subj = PathsFromStr("200,400, 500,540 800,400  760,800 240,800");
      ////subj = PathsFromStr("200,400, 500,540 800,400  760,800 240,800\n\n700,700 700,600 300,600 300,700");

      int scaleBy = 10;
      subj = LoadPathsFromResource("ConsoleDemo2.australia.bin", scaleBy);
      subj = AffineTranslatePaths(subj, -35 * scaleBy, -45 * scaleBy);
      //subj = LoadPathsFromResource("ConsoleDemo2.polygon.bin", scaleBy);

      clip = LoadPathsFromResource("ConsoleDemo2.clip.bin", scaleBy);

      Clipper2 c = new Clipper2();
      c.AddPaths(subj, PolyType.Subject);
      c.AddPaths(clip, PolyType.Clip);
      try
      { c.Execute(ct, sol, sol_open, ft); }
      catch
      {
        Console.Beep();
        return;
      }

      //now do a simple polygon offset of the clipping result ...
      sol = Clipper2Offset.OffsetPaths(sol, -3 * scaleBy, JoinType.Round, EndType.Polygon);

      /////////////////////////////////////////////////////////////////////////
      // LOAD ERROR FILE ...
      /////////////////////////////////////////////////////////////////////////

      //if (!LoadTestNum("error.txt", 1, subj, subj_open, clip, out ct, out ft)) return;
      //Clipper2 c = new Clipper2();
      //c.AddPaths(subj, PolyType.Subject);
      //c.AddPaths(subj_open, PolyType.Subject, true);
      //c.AddPaths(clip, PolyType.Clip);
      //try
      //{ c.Execute(ct, sol, sol_open, ft); }
      //catch
      //{        
      //  Console.Beep();
      //  return;
      //}

      ///////////////////////////////////////////////////////////////////////////
      //// DO RANDOM TESTS ...
      ///////////////////////////////////////////////////////////////////////////

      //Random rand = new Random();
      //int loopCnt = 10;
      //for (int i = 0; i < loopCnt; i++)
      //{
      //  subj.Clear(); clip.Clear(); sol.Clear(); sol_open.Clear();
      //  subj.Add(MakeRandomPath(displayWidth, displayHeight, 100, rand));
      //  clip.Add(MakeRandomPath(displayWidth, displayHeight, 100, rand));
      //  Clipper2 c = new Clipper2();
      //  c.AddPaths(subj, PolyType.Subject);
      //  c.AddPaths(clip, PolyType.Clip);
      //  try
      //  { c.Execute(ct, sol, sol_open, ft); }
      //  catch
      //  {
      //    SaveToFile("error.txt", subj, subj_open, clip, ct, ft);
      //    Console.Beep();
      //    return;
      //  }
      //}

      /////////////////////////////////////////////////////////////////////////
      // Test polytree ...
      /////////////////////////////////////////////////////////////////////////

      //subj.Clear(); clip.Clear(); sol.Clear(); sol_open.Clear();
      //subj = PathsFromStr("200,400, 500,540 800,400  760,800 240,800\n\n700,700 700,600 300,600 300,700");
      //PolyTree pt = new PolyTree();
      //Clipper2 c = new Clipper2();
      //c.AddPaths(subj, PolyType.Subject);
      //c.AddPaths(clip, PolyType.Clip);
      //try
      //{
      //  c.Execute(ct, pt, subj_open, ft);
      //  sol = pt.PolyTreeToPaths();
      //}
      //catch
      //{
      //  Console.Beep();
      //  return;
      //}

      /////////////////////////////////////////////////////////////////////////
      // DO STORED TESTS ...
      /////////////////////////////////////////////////////////////////////////

      //int cnt = 0;
      //int numStart = 1, numEnd = 1000; //1->85
      //for (int i = numStart; i <= numEnd; i++)
      //{
      //  if (!LoadTestNum("..\\..\\tests.txt", i, subj, subj_open, clip, out ct, out ft)) break;

      //  Clipper2 c = new Clipper2();
      //  c.AddPaths(subj, PolyType.Subject);
      //  c.AddPaths(subj_open, PolyType.Subject, true);
      //  c.AddPaths(clip, PolyType.Clip);
      //  try
      //  { c.Execute(ct, sol, sol_open, ft); }
      //  catch
      //  {
      //    SaveToFile("..\\..\\error.txt", subj, subj_open, clip, ct, ft);
      //    Console.Beep();
      //    return;
      //  }
      //  cnt++;
      //}
      //Console.Write("{0} tests completed successfully.\n\n", cnt);
      //Console.Write("Press any key to continue ... ");
      //Console.ReadKey();

      /////////////////////////////////////////////////////////////////////////
      //DISPLAY AS SVG FILE ...

      SVGBuilder svg = new SVGBuilder();
      //svg.style.showCoords = true;
      svg.style.fillType = ft;
      svg.AddPaths(subj, 0x330066FF, 0x99000033, true);
      svg.AddPaths(subj_open, 0, 0xFF0099FF, false);
      svg.AddPaths(clip, 0x33996600, 0x99993300, true);
      svg.AddPaths(sol, 0x9900FF00, 0xFF000000, true);
      svg.AddPaths(sol_open, 0, 0xFF000000, false);
      svg.SaveToFile("..\\..\\clipper.svg", displayWidth, displayHeight, border);

    } //Main()

  } //class Application

} //namespace
