﻿/*******************************************************************************
*                                                                              *
* Author    :  Angus Johnson                                                   *
* Date      :  14 September 2017                                               *
* Website   :  http://www.angusj.com                                           *
* Copyright :  Angus Johnson 2010-2017                                         *
*                                                                              *
* License:                                                                     *
* Use, modification & distribution is subject to Boost Software License Ver 1. *
* http://www.boost.org/LICENSE_1_0.txt                                         *
*                                                                              *
*******************************************************************************/

using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Diagnostics; //for Stopwatch
using ClipperLib;
using SVG;

namespace ClipperDemo1
{

  using Path = List<Point64>;
  using Paths = List<List<Point64>>;

  class Application
  {

    //-----------------------------------------------------------------------
    //-----------------------------------------------------------------------

    static Paths PathFromStr(string s)
    {
      if (s == null) return null;
      Path p = new Path();
      Paths pp = new Paths();
      int len = s.Length, i = 0, j;
      while (i < len)
      {
        Int64 y, x;
        bool isNeg;
        while ((int)s[i] < 33 && i < len) i++;
        if (i >= len) break;
        //get X ...
        isNeg = (int)s[i] == 45;
        if (isNeg) i++;
        if (i >= len || (int)s[i] < 48 || (int)s[i] > 57) break;
        j = i + 1;
        while (j < len && (int)s[j] > 47 && (int)s[j] < 58) j++;
        if (!Int64.TryParse(s.Substring(i, j - i), out x)) break;
        if (isNeg) x = -x;
        //skip space or comma between X & Y ...
        i = j;
        while (i < len && ((int)s[i] == 32 || (int)s[i] == 44)) i++;
        //get Y ...
        if (i >= len) break;
        isNeg = (int)s[i] == 45;
        if (isNeg) i++;
        if (i >= len || (int)s[i] < 48 || (int)s[i] > 57) break;
        j = i + 1;
        while (j < len && (int)s[j] > 47 && (int)s[j] < 58) j++;
        if (!Int64.TryParse(s.Substring(i, j - i), out y)) break;
        if (isNeg) y = -y;
        p.Add(new Point64(x, y));
        //skip trailing space, comma ...
        i = j;
        int nlCnt = 0;
        while (i < len && ((int)s[i] < 33 || (int)s[i] == 44))
        {
          if (i >= len) break;
          if ((int)s[i] == 10)
          {
            nlCnt++;
            if (nlCnt == 2)
            {
              if (p.Count > 2) pp.Add(p);
              p = new Path();
            }
          }
          i++;
        }
      }
      if (p.Count > 2) pp.Add(p);
      return pp;
    }
    //------------------------------------------------------------------------------

    static bool LoadTestNum(string filename, int num, 
      Paths subj, Paths subj_open, Paths clip, out ClipType ct, out FillRule ft)
    {
      if (subj == null) subj = new Paths(); else subj.Clear();
      if (subj_open == null) subj_open = new Paths(); else subj_open.Clear();
      if (clip == null) clip = new Paths(); else clip.Clear();
      ct = ClipType.Intersection;
      ft = FillRule.EvenOdd;
      bool numFound = false, result = false;
      int GetIdx = 0;
      string numstr = num.ToString();
      StreamReader reader = new StreamReader(filename);
      if (reader == null) return false;
      while (true)
      {
        string s = reader.ReadLine();
        if (s == null) break;

        if (s.IndexOf("CAPTION: ") == 0)
        {
          numFound = (s.IndexOf(numstr) > 0);
          if (numFound) result = true;
          continue;
        }

        if (!numFound) continue;

        if (s.IndexOf("CLIPTYPE: ") == 0)
        {
          if (s.IndexOf("INTERSECTION") > 0) ct = ClipType.Intersection;
          else if (s.IndexOf("UNION") > 0) ct = ClipType.Union;
          else if (s.IndexOf("INTERSECTION") > 0) ct = ClipType.Difference;
          else ct = ClipType.Xor;
          continue;
        }

        if (s.IndexOf("FILLTYPE: ") == 0)
        {
          if (s.IndexOf("EVENODD") > 0) ft = FillRule.EvenOdd;
          else ft = FillRule.NonZero;
          continue;
        }

        if (s.IndexOf("SUBJECTS_OPEN") == 0) GetIdx = 2;
        else if (s.IndexOf("SUBJECTS") == 0) GetIdx = 1;
        else if (s.IndexOf("CLIPS") == 0) GetIdx = 3;
        else continue;

        while (true)
        {
          s = reader.ReadLine();
          Paths paths = PathFromStr(s); //0 or 1 path
          if (paths == null || paths.Count == 0)
          {
            if (GetIdx == 3) return result;
            else if (s.IndexOf("SUBJECTS_OPEN") == 0) GetIdx = 2;
            else if (s.IndexOf("CLIPS") == 0) GetIdx = 3;
            else return result;
            continue;
          }
          if (GetIdx == 1) subj.Add(paths[0]);
          else if (GetIdx == 2) subj_open.Add(paths[0]);
          else clip.Add(paths[0]);
        }
      }
      return result;
    }
    //-----------------------------------------------------------------------

    public static void SaveToFile(string filename, Paths subj, 
      Paths subj_open, Paths clip, ClipType ct, FillRule ft)
    {
      StreamWriter writer = new StreamWriter(filename);
      if (writer == null) return;
      writer.Write("CAPTION: 1. \r\n");
      writer.Write("CLIPTYPE: {0}\r\n", ct.ToString().ToUpper());
      writer.Write("FILLTYPE: {0}\r\n", ft.ToString().ToUpper());
      if (subj != null && subj.Count > 0)
      {
        writer.Write("SUBJECTS\r\n");
        foreach (Path p in subj)
        {
          foreach (Point64 ip in p)
            writer.Write("{0},{1} ", ip.X, ip.Y);
          writer.Write("\r\n");
        }
      }
      if (subj_open != null && subj_open.Count > 0)
      {
        writer.Write("SUBJECTS_OPEN\r\n");
        foreach (Path p in subj_open)
        {
          foreach (Point64 ip in p)
            writer.Write("{0},{1} ", ip.X, ip.Y);
          writer.Write("\r\n");
        }
      }
      if (clip != null && clip.Count > 0)
      {
        writer.Write("CLIPS\r\n");
        foreach (Path p in clip)
        {
          foreach (Point64 ip in p)
            writer.Write("{0},{1} ", ip.X, ip.Y);
          writer.Write("\r\n");
        }
      }
      writer.Close();
    }
    //-----------------------------------------------------------------------

    private static Point64 MakeRandomPt(int maxWidth, int maxHeight, 
      int rndTo, Random rand)
    {
      Point64 pt = new Point64();
      pt.X = (Int64)(rand.Next(maxWidth / rndTo) * rndTo);
      pt.Y = (Int64)(rand.Next(maxHeight / rndTo) * rndTo);
      return pt;
    }
    //---------------------------------------------------------------------

    public static Path MakeRandomPath(int width, int height, int count, Random rand)
    {
      int roundTo = 10;
      rand.Next();
      Path result = new Path(count);
      for (int i = 0; i < count; ++i)
        result.Add(MakeRandomPt(width, height, roundTo, rand));
      return result;
    }
    //---------------------------------------------------------------------

    public static Paths LoadPathsFromResource(string resourceName, double scaleBy = 1)
    {
      using (Stream stream = Assembly.GetExecutingAssembly().GetManifestResourceStream(resourceName))
      using (BinaryReader reader = new BinaryReader(stream))
      {
        int len = reader.ReadInt32();
        Paths result = new Paths(len);
        for (int i = 0; i < len; i++)
        {
          int len2 = reader.ReadInt32();
          Path p = new Path(len2);
          for (int j = 0; j < len2; j++)
          {
            float x = reader.ReadSingle();
            float y = reader.ReadSingle();
              p.Add(new Point64(x * scaleBy, y * scaleBy));
          }
          result.Add(p);
        }
        return result;
      }
    }
    //-----------------------------------------------------------------------

    public static Paths AffineTranslatePaths(Paths paths, Int64 dx, Int64 dy)
    {
      Paths result = new Paths(paths.Count);
      foreach (Path path in paths)
      {
        Path p = new Path(path.Count);
        foreach (Point64 pt in path)
          p.Add(new Point64(pt.X + dx, pt.Y + dy));
        result.Add(p);
      }
      return result;
    }
    //-----------------------------------------------------------------------

    public static void Main(string[] args)
    {
      const int displayWidth = 1024, displayHeight = 768, margin = 60;

      Paths subj = new Paths();
      Paths subj_open = new Paths();
      Paths clip = new Paths();
      Paths sol = new Paths();
      Paths sol_open = new Paths();

      ClipType clipType = ClipType.Intersection;
      FillRule fillRule = FillRule.EvenOdd;
      bool displaySolutionCoords = false;

      /////////////////////////////////////////////////////////////////////////
      // LOAD PATHS FROM RESOURCE ...
      /////////////////////////////////////////////////////////////////////////

      //subj = PathFromStr("690, 370 160, 150 230, 150 160, 150 250, 280");
      //clip = PathFromStr("650, 10 160, 290 200, 80 50, 340");

      //scaling removes noticeable rounding artefacts if later offsetting 
      int scaleBy = 10;
      //subj = LoadPathsFromResource("ConsoleDemo2.australia.bin", scaleBy);
      //subj = AffineTranslatePaths(subj, -35 * scaleBy, -45 * scaleBy);
      subj = LoadPathsFromResource("ConsoleDemo2.polygon.bin", scaleBy);
      clip = LoadPathsFromResource("ConsoleDemo2.clip.bin", scaleBy);

      Clipper c = new Clipper();
      c.AddPaths(subj, PathType.Subject);
      c.AddPaths(subj_open, PathType.Subject, true);
      c.AddPaths(clip, PathType.Clip);
      try
      { c.Execute(clipType, sol, sol_open, fillRule); }
      catch
      {
        Console.Write("Oops, something is broken!\n\n");
        Console.ReadKey();
        return;
      }
      //offset the solution of the clipping op. ...
      sol = ClipperOffset.OffsetPaths(sol, -3 * scaleBy, JoinType.Round, EndType.Polygon);

      /////////////////////////////////////////////////////////////////////////
      // LOAD AN ERROR FILE ...
      /////////////////////////////////////////////////////////////////////////

      //if (!LoadTestNum("error.txt", 1, subj, subj_open, clip, out ct, out ft)) return;
      //Clipper c = new Clipper();
      //c.AddPaths(subj, PathType.Subject);
      //c.AddPaths(subj_open, PathType.Subject, true);
      //c.AddPaths(clip, PathType.Clip);
      //try
      //{ c.Execute(ct, sol, sol_open, ft); }
      //catch
      //{        
      //  Console.Write("Oops, something is broken!\n\n");
      //  Console.ReadKey();
      //  return;
      //}

      ///////////////////////////////////////////////////////////////////////////
      //// DO RANDOM TESTS ...
      ///////////////////////////////////////////////////////////////////////////

      //      Random rand = new Random();
      //      int loopCnt = 1000;
      //      int edgeCnt = 100;
      //      Stopwatch stopwatch = new Stopwatch();
      //      stopwatch.Start(); //////////////////////////////////// start of loop
      //      for (int i = 0; i < loopCnt; i++)
      //      {
      //        subj.Clear(); clip.Clear(); sol.Clear(); sol_open.Clear();
      //        subj.Add(MakeRandomPath(displayWidth, displayHeight, edgeCnt, rand));
      //        clip.Add(MakeRandomPath(displayWidth, displayHeight, edgeCnt, rand));
      //        Clipper c = new Clipper();
      //#if clipper1
      //        c.AddPaths(subj, PathType.ptSubject, true);
      //        c.AddPaths(clip, PathType.ptClip, true);
      //#else
      //        c.AddPaths(subj, PathType.Subject);
      //        c.AddPaths(clip, PathType.Clip);
      //#endif
      //        try
      //        {
      //#if clipper1
      //          c.Execute(ct, sol, ft);
      //#else
      //          c.Execute(ct, sol, sol_open, ft);
      //#endif
      //        }
      //        catch
      //        {
      //          SaveToFile("error.txt", subj, subj_open, clip, ct, ft);
      //          Console.Beep();
      //          return;
      //        }
      //      }
      //      stopwatch.Stop();
      //      Console.WriteLine("\n\nExecution time was " + stopwatch.ElapsedMilliseconds + " millisecs.\n\n");
      //      Console.ReadKey();
      //      //sol = ClipperOffset.OffsetPaths(sol, -5, JoinType.Round, EndType.Polygon);

      /////////////////////////////////////////////////////////////////////////
      // DO STORED TESTS (not comparing with stored solutions) ...
      /////////////////////////////////////////////////////////////////////////

      //int cnt = 0;
      //int numStart = 1, numEnd = 1000; //1->85
      //for (int i = numStart; i <= numEnd; i++)
      //{
      //  if (!LoadTestNum("..\\..\\tests.txt", i, subj, subj_open, clip, out ct, out ft)) break;

      //  Clipper c = new Clipper();
      //  c.AddPaths(subj, PathType.Subject);
      //  c.AddPaths(subj_open, PathType.Subject, true);
      //  c.AddPaths(clip, PathType.Clip);
      //  try
      //  { c.Execute(ct, sol, sol_open, ft); }
      //  catch
      //  {
      //    SaveToFile("..\\..\\error.txt", subj, subj_open, clip, ct, ft);
      //    Console.Write("Oops, something is broken!\n\n");
      //    Console.Write("Press any key to continue ... ");
      //    Console.ReadKey();
      //    return;
      //  }
      //  cnt++;
      //}
      //Console.Write("{0} tests completed successfully.\n\n", cnt);
      //Console.ReadKey();

      /////////////////////////////////////////////////////////////////////////
      //FINALLY, DISPLAY THE LAST TEST IN AN SVG FILE ...
      /////////////////////////////////////////////////////////////////////////

      SVGBuilder svg = new SVGBuilder();
      svg.FillRule = fillRule;
      svg.SetCaption("Clipper test ...", SVGBuilder.navy, 14, margin, margin);
      svg.AddPaths(subj, false, 0x330066FF, 0x99000033, 0.8);
      svg.AddPaths(subj_open, true, 0, 0xFF0099FF, 0.8);
      svg.AddPaths(clip, false, 0x33996600, 0x99993300, 0.8);
      svg.AddPaths(sol, false, 0x9900FF00, 0xFF000000, 0.8, displaySolutionCoords);
      svg.AddPaths(sol_open, true, 0, 0xFF000000, 0.8);
      svg.SaveToFile("..\\..\\clipper.svg", displayWidth, displayHeight, margin);
      Process.Start("..\\..\\clipper.svg");
    } //Main()

  } //class Application

} //namespace
