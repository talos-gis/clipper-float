﻿/*******************************************************************************
*                                                                              *
* Author    :  Angus Johnson                                                   *
* Date      :  14 September 2017                                               *
* Website   :  http://www.angusj.com                                           *
* Copyright :  Angus Johnson 2010-2017                                         *
*                                                                              *
* License:                                                                     *
* Use, modification & distribution is subject to Boost Software License Ver 1. *
* http://www.boost.org/LICENSE_1_0.txt                                         *
*                                                                              *
*******************************************************************************/

using System;
using System.Drawing;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Globalization;
using ClipperLib;

namespace SVG
{

  using Path = List<Point64>;
  using Paths = List<List<Point64>>;

  //a simple class to build SVG files that display Paths ...
  class SVGBuilder
  {

    public static Rect64 r64Max = new Rect64(Int64.MaxValue,
      Int64.MaxValue, -Int64.MaxValue, -Int64.MaxValue);

    internal class CoordStyle
    {
      public string fontName;
      public int fontSize;
      public UInt32 fontColor;
    }

    internal class CaptionInfo
    {
      public string caption;
      public int fontSize;
      public UInt32 fontColor;
      public int posX;
      public int posY;
    }

    internal class PolyInfo
    {
      public Paths paths = new Paths();
      public UInt32 brushClr;
      public UInt32 penClr;
      public double penWidth;
      public bool showCoords;
      public bool IsOpen;
    }

    public FillRule FillRule { get; set; }
    private List<PolyInfo> PolyInfoList = new List<PolyInfo>();
    private CaptionInfo captionInfo = new CaptionInfo();
    private CoordStyle coordStyle = new CoordStyle();

    public const UInt32 black  = 0xFF000000;
    public const UInt32 white  = 0xFFFFFFFF;
    public const UInt32 maroon = 0xFF800000;

    public const UInt32 navy = 0xFF000080;
    public const UInt32 blue = 0xFF0000FF;
    public const UInt32 red = 0xFFFF0000;
    public const UInt32 green = 0xFF008000;
    public const UInt32 yellow = 0xFFFFFF00;
    public const UInt32 lime = 0xFF00FF00;
    public const UInt32 fuscia = 0xFFFF00FF;
    public const UInt32 aqua = 0xFF00FFFF;

    private const string svg_header = "<?xml version=\"1.0\" standalone=\"no\"?>\n" +
      "<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.0//EN\"\n" +
      "\"http://www.w3.org/TR/2001/REC-SVG-20010904/DTD/svg10.dtd\">\n\n" +
      "<svg width=\"{0}px\" height=\"{1}px\" viewBox=\"0 0 {0} {1}\"" +
      " version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\">\n\n";
    private const string svg_path_format = "\"\n style=\"fill:{0};" +
        " fill-opacity:{1:f2}; fill-rule:{2}; stroke:{3};" +
        " stroke-opacity:{4:f2}; stroke-width:{5:f2};\"/>\n\n";
    private const string svg_path_format2 = "\"\n style=\"fill:none; stroke:{0};" +
        "stroke-opacity:{1:f2}; stroke-width:{2:f2};\"/>\n\n";

    //------------------------------------------------------------------------------
    //------------------------------------------------------------------------------

    public SVGBuilder(string fontName = "Verdana", int fontsize = 10, UInt32 fontColor = black)
    {
      coordStyle.fontName = fontName;
      coordStyle.fontSize = fontsize;
      coordStyle.fontColor = fontColor;
    }

    public void AddPaths(Paths paths, bool IsOpen, UInt32 brushColor, 
      UInt32 penColor, double penWidth, bool showCoords = false)
    {
      if (paths.Count == 0) return;
      PolyInfo pi = new PolyInfo();
      pi.brushClr = brushColor;
      pi.penClr = penColor;
      pi.penWidth = penWidth;
      pi.paths = paths;
      pi.IsOpen = IsOpen;
      pi.showCoords = showCoords;
      PolyInfoList.Add(pi);
    }
    //------------------------------------------------------------------------------

    public void SetCaption(string caption, UInt32 fontClr, int fontSize, int posX, int posY)
    {
      captionInfo.caption = caption;
      captionInfo.fontColor = fontClr;
      captionInfo.fontSize = fontSize;
      captionInfo.posX = posX;
      captionInfo.posY = posY;
    }
    //------------------------------------------------------------------------------

    private Rect64 GetBounds()
    {
      Rect64 bounds = new Rect64(r64Max);
      foreach (PolyInfo pi in PolyInfoList)
        foreach (Path path in pi.paths)
          foreach (Point64 pt in path) {
            if (pt.X < bounds.left) bounds.left = pt.X;
            if (pt.X > bounds.right) bounds.right = pt.X;
            if (pt.Y < bounds.top) bounds.top = pt.Y;
            if (pt.Y > bounds.bottom) bounds.bottom = pt.Y;
          }
      return bounds;
    }
    //------------------------------------------------------------------------------

    private string ColorToHtml(UInt32 clr)
    {
      return '#' + (clr & 0xFFFFFF).ToString("X6");
    }
    //------------------------------------------------------------------------------

    float GetAlpha(UInt32 clr)
    {
      return ((float)(clr >> 24) / 255);
    }
    //------------------------------------------------------------------------------

    public bool SaveToFile(string filename, int MaxWidth, int MaxHeight, int margin = 20)
    {
      if (margin < 20) margin = 20;
      Rect64 bounds = GetBounds();
      if (bounds.left >= bounds.right || bounds.top >= bounds.bottom) return false;

      double scale = 1.0;
      if (MaxWidth > 0 && MaxHeight > 0)
        scale = 1.0 / Math.Max((double)(bounds.right - bounds.left) / (MaxWidth - margin * 2),
          (double)(bounds.bottom - bounds.top) / (MaxHeight - margin * 2));

      Int64 offsetX = margin - (Int64)((double)bounds.left * scale);
      Int64 offsetY = margin - (Int64)((double)bounds.top * scale);

      StreamWriter writer = new StreamWriter(filename);
      if (writer == null) return false;

      if (MaxWidth <= 0 || MaxHeight <= 0) 
        writer.Write(svg_header, (bounds.right - bounds.left) + margin * 2,
          (bounds.bottom - bounds.top) + margin * 2);
      else
        writer.Write(svg_header, MaxWidth, MaxHeight);

      foreach (PolyInfo pi in PolyInfoList)
      {
        writer.Write(" <path d=\"");
        foreach (Path path in pi.paths) {
          if ((!pi.IsOpen && path.Count < 3)) continue;
          writer.Write(string.Format(NumberFormatInfo.InvariantInfo, " M {0:f2} {1:f2}",
              (double)((double)path[0].X * scale + offsetX),
              (double)((double)path[0].Y * scale + offsetY)));
          foreach (Point64 pt in path.Skip(1)) {
            writer.Write(string.Format(NumberFormatInfo.InvariantInfo, " L {0:f2} {1:f2}",
            (double)((double)pt.X * scale + offsetX),
            (double)((double)pt.Y * scale + offsetY)));
          }
          if (!pi.IsOpen) writer.Write(" z");
        }

        if (!pi.IsOpen)
          writer.Write(string.Format(NumberFormatInfo.InvariantInfo, svg_path_format,
              ColorToHtml(pi.brushClr), GetAlpha(pi.brushClr),
              (FillRule == FillRule.EvenOdd ? "evenodd" : "nonzero"),
              ColorToHtml(pi.penClr), GetAlpha(pi.penClr), pi.penWidth));
        else
          writer.Write(string.Format(NumberFormatInfo.InvariantInfo, svg_path_format2,
              ColorToHtml(pi.penClr), GetAlpha(pi.penClr), pi.penWidth));

        if (pi.showCoords) {
          writer.Write(string.Format("<g font-family=\"{0}\" font-size=\"{1}\" fill=\"{2}\">\n\n",
            coordStyle.fontName, coordStyle.fontSize, ColorToHtml(coordStyle.fontColor)));
          foreach (Path path in pi.paths) {
            foreach (Point64 pt in path) {
              writer.Write(string.Format(
                  "<text x=\"{0}\" y=\"{1}\">{2},{3}</text>\n",
                  (int)(pt.X * scale + offsetX), (int)(pt.Y * scale + offsetY), pt.X, pt.Y));

            }
            writer.Write("\n");
          }
          writer.Write("</g>\n");
        }
      }

      if (captionInfo.caption.Trim() != "")
      {
        writer.Write(string.Format(
            "<g font-family=\"Verdana\" font-style=\"normal\" " +
            "font-weight=\"normal\" font-size=\"{0}\" fill=\"{1}\">\n",
            captionInfo.fontSize, ColorToHtml(captionInfo.fontColor)));
        writer.Write(string.Format(
            "<text x=\"{0}\" y=\"{1}\">{2}</text>\n</g>\n\n",
            captionInfo.posX, captionInfo.posY, captionInfo.caption));
      }

      writer.Write("</svg>\n");
      writer.Close();
      return true;
    }
  } //ends SVGBuilder

}
